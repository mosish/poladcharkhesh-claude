# What to do with this archive

Your repository at `mosish/poladcharkhesh-claude` currently holds the **first**
snapshot (design system + home page). It is byte-for-byte correct — nothing was
lost in the upload, dotfiles included. What it is missing is the second stage of
work: the admin panel, the schematic corrections and the `.com`-primary change.

This archive is the difference. Unzip it over your local copy of the repository,
or drag its contents into GitHub's web uploader — every path here is relative to
the repository root, so folders land in the right place.

## 54 files to add or replace

- `app/Http/Admin/…`, `app/Views/admin/…`, `app/Storage/{Admin,Audit,Session,Throttle}Repository.php`,
  `app/Support/{Auth,ImageIntake}.php` — the admin panel
- `src/admin.ts`, `src/islands/media-editor.ts`, `src/styles/08-admin.css`,
  `public/assets/js/admin.*.js`, `public/assets/css/site.0e8c55800b.css`,
  `public/assets/manifest.json` — the panel's front end and the rebuilt assets
- `public/assets/uploads/.htaccess` — **important**: this turns off PHP execution
  in the upload directory. Some upload tools skip dotfiles; confirm it arrived.
- `data/store/{products,seo,company,media,audit}.json` — the 13 schematic
  corrections, `.com` as primary host, and the media registry
- `docs/ADMIN.md` plus updates to the other four documents
- `tests/admin_flow.sh`, `scripts/apply_schematic_corrections.py`,
  `scripts/screenshots_admin.mjs` — verification
- `package-lock.json` — absent from the upload

## One file to delete

`public/assets/css/site.f2d61ac0cf.css`

It is the previous stylesheet build. The new `manifest.json` no longer points at
it, so leaving it does no harm — it is just dead weight.

## After uploading

Nothing needs building. The compiled CSS and JS in this archive are current, and
the host does not run Node.

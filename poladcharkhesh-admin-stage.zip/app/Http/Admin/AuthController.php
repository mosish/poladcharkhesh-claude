<?php

declare(strict_types=1);

namespace App\Http\Admin;

use App\Core\App;
use App\Core\Request;
use App\Core\Response;
use App\Support\Auth;

/**
 * First-run provisioning, sign-in and sign-out.
 *
 * No credentials ship with the application. The setup route creates the first
 * administrator and is reachable only while no account exists, so the window
 * closes the moment it is used.
 *
 * Sign-in failures are throttled on two keys — address plus username, and
 * address alone — so neither guessing one password nor working through a list
 * of usernames gets an unlimited number of tries. The response never
 * distinguishes an unknown username from a wrong password.
 */
final class AuthController
{
    private const FAIL_LIMIT_PAIR = 5;
    private const FAIL_LIMIT_IP = 20;
    private const WINDOW = 900;   // 15 minutes
    private const LOCK = 900;     // 15 minutes

    /** A real bcrypt hash of a value nobody knows, used only to equalise timing. */
    private const TIMING_PLACEHOLDER_HASH = '$2y$12$//CoBfux.2zUGeolEh4qRO2U1GLegz42Vc/4i.WRoeTbPVLXqeLM2';

    public function __construct(
        private readonly App $app,
        private readonly Guard $guard,
    ) {
    }

    // ------------------------------------------------------------------ setup

    public function showSetup(Request $request): Response
    {
        if ($this->app->admins()->isProvisioned()) {
            return Response::redirect('/admin/login');
        }

        return $this->render('admin/setup', [
            'title' => 'Create the first administrator',
            'errors' => [],
            'values' => [],
        ]);
    }

    public function submitSetup(Request $request): Response
    {
        if ($this->app->admins()->isProvisioned()) {
            return Response::redirect('/admin/login');
        }

        $username = trim((string) ($request->body['username'] ?? ''));
        $name = trim((string) ($request->body['name'] ?? ''));
        $email = trim((string) ($request->body['email'] ?? ''));
        $password = (string) ($request->body['password'] ?? '');
        $confirm = (string) ($request->body['password_confirm'] ?? '');

        $errors = [];

        if (!preg_match('/^[a-zA-Z0-9._-]{3,32}$/', $username)) {
            $errors['username'] = 'Use 3–32 characters: letters, digits, dot, dash or underscore.';
        }
        if ($name === '' || mb_strlen($name, 'UTF-8') > 80) {
            $errors['name'] = 'Enter a name, up to 80 characters.';
        }
        if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            $errors['email'] = 'That does not look like an email address.';
        }
        if ($password !== $confirm) {
            $errors['password_confirm'] = 'The two passwords do not match.';
        }

        foreach (Auth::passwordProblems($password, $username) as $problem) {
            $errors['password'] = match ($problem) {
                'tooShort' => 'Use at least 12 characters. Length matters more than symbols.',
                'common' => 'That contains a very common word. Pick something less guessable.',
                'containsUsername' => 'Do not put the username in the password.',
                'blank' => 'Enter a password.',
                default => 'Choose a different password.',
            };
            break;
        }

        if ($errors !== []) {
            return $this->render('admin/setup', [
                'title' => 'Create the first administrator',
                'errors' => $errors,
                'values' => ['username' => $username, 'name' => $name, 'email' => $email],
            ], 422);
        }

        try {
            $admin = $this->app->admins()->createFirst($username, $password, $name, $email);
        } catch (\RuntimeException) {
            // Another request won the race between the check and the write.
            return Response::redirect('/admin/login');
        }

        $this->app->audit()->log(
            'ADMIN_PROVISIONED',
            $admin,
            (string) $admin['id'],
            'First administrator created through first-run setup.'
        );

        $token = $this->app->sessions()->create(
            (string) $admin['id'],
            $request->clientIp(),
            $request->userAgent
        );
        Guard::setCookie($token, $request->secure);
        $this->app->admins()->recordLogin((string) $admin['id']);

        return Response::redirect('/admin');
    }

    // ------------------------------------------------------------------ login

    public function showLogin(Request $request): Response
    {
        if (!$this->app->admins()->isProvisioned()) {
            return Response::redirect('/admin/setup');
        }
        if ($this->guard->isSignedIn()) {
            return Response::redirect('/admin');
        }

        return $this->render('admin/login', [
            'title' => 'Sign in',
            'error' => $this->flashFor($request->queryString('reason')),
            'next' => self::safeNext($request->queryString('next')),
            'username' => '',
        ]);
    }

    public function submitLogin(Request $request): Response
    {
        if (!$this->app->admins()->isProvisioned()) {
            return Response::redirect('/admin/setup');
        }

        $username = trim((string) ($request->body['username'] ?? ''));
        $password = (string) ($request->body['password'] ?? '');
        $next = self::safeNext((string) ($request->body['next'] ?? ''));
        $ip = $request->clientIp();

        $throttle = $this->app->throttle();
        $pairKey = $ip . '|' . mb_strtolower($username, 'UTF-8');

        $locked = max(
            $throttle->lockedFor('login-pair', $pairKey),
            $throttle->lockedFor('login-ip', $ip)
        );
        if ($locked > 0) {
            $this->app->audit()->log(
                'LOGIN_THROTTLED',
                null,
                $username,
                sprintf('Sign-in refused while locked, %d seconds remaining.', $locked)
            );

            return $this->render('admin/login', [
                'title' => 'Sign in',
                'error' => sprintf(
                    'Too many attempts. Try again in about %d minutes.',
                    max(1, (int) ceil($locked / 60))
                ),
                'next' => $next,
                'username' => $username,
            ], 429);
        }

        $admin = $username === '' ? null : $this->app->admins()->findByUsername($username);
        $hash = (string) ($admin['passwordHash'] ?? '');

        if ($admin !== null) {
            $valid = Auth::verifyPassword($password, $hash);
        } else {
            // Spend comparable time against a real hash of a value nobody
            // knows, so how long the response takes does not reveal which
            // usernames exist. The result is discarded.
            Auth::verifyPassword($password, self::TIMING_PLACEHOLDER_HASH);
            $valid = false;
        }

        if (!$valid) {
            $throttle->fail('login-pair', $pairKey, self::FAIL_LIMIT_PAIR, self::WINDOW, self::LOCK);
            $throttle->fail('login-ip', $ip, self::FAIL_LIMIT_IP, self::WINDOW, self::LOCK);

            $this->app->audit()->log('LOGIN_FAILED', null, $username, 'Sign-in failed.');

            return $this->render('admin/login', [
                'title' => 'Sign in',
                'error' => 'Those details were not accepted.',
                'next' => $next,
                'username' => $username,
            ], 401);
        }

        // Upgrade the stored hash if the parameters have since been raised.
        if (Auth::needsRehash($hash)) {
            $this->app->admins()->updatePasswordHash((string) $admin['id'], Auth::hashPassword($password));
        }

        $throttle->clear('login-pair', $pairKey);
        $throttle->clear('login-ip', $ip);

        $token = $this->app->sessions()->create((string) $admin['id'], $ip, $request->userAgent);
        Guard::setCookie($token, $request->secure);
        $this->app->admins()->recordLogin((string) $admin['id']);

        unset($admin['passwordHash']);
        $this->app->audit()->log('LOGIN', $admin, (string) $admin['id'], 'Signed in.');

        return Response::redirect($next !== '' ? $next : '/admin');
    }

    // ----------------------------------------------------------------- logout

    public function logout(Request $request): Response
    {
        if ($csrf = $this->guard->requireCsrf($request)) {
            return $csrf;
        }

        $token = $this->guard->sessionToken();
        if ($token !== null) {
            $this->app->audit()->log('LOGOUT', $this->guard->admin(), '', 'Signed out.');
            $this->app->sessions()->revoke($token, 'logout');
        }
        Guard::setCookie(null, $request->secure);

        return Response::redirect('/admin/login');
    }

    // ------------------------------------------------------------------ utils

    /**
     * Only same-site absolute paths are accepted as a redirect target, so a
     * crafted `?next=` cannot bounce someone to another host after sign-in.
     */
    private static function safeNext(string $next): string
    {
        if ($next === '' || !str_starts_with($next, '/admin')) {
            return '';
        }
        if (str_starts_with($next, '//') || str_contains($next, "\n") || str_contains($next, "\r")) {
            return '';
        }

        return $next;
    }

    private function flashFor(string $reason): string
    {
        return match ($reason) {
            'expired' => 'That session expired. Sign in again.',
            'password' => 'Your password was changed. Sign in again.',
            default => '',
        };
    }

    /** @param array<string,mixed> $data */
    private function render(string $template, array $data, int $status = 200): Response
    {
        return Response::html(
            $this->app->view()->page($template, $data + [
                'guard' => $this->guard,
                'bare' => true,
            ], 'admin/layout-bare'),
            $status
        );
    }
}

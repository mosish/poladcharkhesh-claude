<?php

declare(strict_types=1);

namespace App\Http\Admin;

use App\Core\App;
use App\Core\Request;
use App\Core\Response;
use App\Domain\Product;

/**
 * The overview, the media library and the audit log.
 *
 * The overview leads with what is actually actionable — how many references
 * still have no usable image — rather than a wall of counts.
 */
final class DashboardController
{
    public function __construct(
        private readonly App $app,
        private readonly Guard $guard,
    ) {
    }

    public function overview(Request $request): Response
    {
        if ($denied = $this->guard->require($request)) {
            return $denied;
        }

        $products = $this->app->products();
        $media = $this->app->media();

        $all = $products->all(true);
        $withImage = array_values(array_filter(
            $all,
            static fn (Product $p): bool => $media->firstUsable($p->gallery()) !== null
        ));

        return $this->render('admin/overview', [
            'title' => 'Overview',
            'counts' => [
                'products' => count($all),
                'active' => count($products->all()),
                'archived' => count($all) - count($products->all()),
                'families' => count($products->familyCounts()),
                'withImage' => count($withImage),
                'withoutImage' => count($all) - count($withImage),
                'uploads' => count($media->uploads()),
                'brokenImports' => count($media->broken()),
            ],
            'recent' => $this->app->audit()->recent(8),
        ]);
    }

    public function media(Request $request): Response
    {
        if ($denied = $this->guard->require($request)) {
            return $denied;
        }

        $uploads = $this->app->media()->uploads();
        uasort($uploads, static fn (array $a, array $b): int =>
            strcmp((string) ($b['uploadedAt'] ?? ''), (string) ($a['uploadedAt'] ?? '')));

        return $this->render('admin/media', [
            'title' => 'Media',
            'uploads' => $uploads,
            'broken' => $this->app->media()->broken(),
        ]);
    }

    public function audit(Request $request): Response
    {
        if ($denied = $this->guard->require($request)) {
            return $denied;
        }

        return $this->render('admin/audit', [
            'title' => 'Audit log',
            'entries' => $this->app->audit()->recent(200),
        ]);
    }

    /** @param array<string,mixed> $data */
    private function render(string $template, array $data, int $status = 200): Response
    {
        return Response::html(
            $this->app->view()->page($template, $data + [
                'guard' => $this->guard,
                'admin' => $this->guard->admin(),
                'csrf' => $this->guard->csrfToken(),
            ], 'admin/layout'),
            $status
        );
    }
}

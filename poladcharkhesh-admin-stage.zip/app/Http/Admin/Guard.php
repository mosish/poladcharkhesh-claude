<?php

declare(strict_types=1);

namespace App\Http\Admin;

use App\Core\App;
use App\Core\Request;
use App\Core\Response;
use App\Support\Auth;

/**
 * The gate in front of every admin route.
 *
 * One object answers three questions: is there a live session, does this
 * request carry a valid CSRF token, and what should happen when either answer
 * is no. Controllers call `require()` first and then act — there is no path
 * into an admin action that skips it.
 */
final class Guard
{
    /** @var array<string,mixed>|null */
    private ?array $admin = null;

    private ?string $token = null;

    private bool $resolved = false;

    public function __construct(private readonly App $app)
    {
    }

    /** Resolve the session once per request. */
    private function resolve(): void
    {
        if ($this->resolved) {
            return;
        }
        $this->resolved = true;

        $token = $this->app->request->cookies[Auth::SESSION_COOKIE] ?? '';
        if ($token === '' || !preg_match('/^[a-f0-9]{64}$/', $token)) {
            return;
        }

        $session = $this->app->sessions()->resolve($token);
        if ($session === null) {
            return;
        }

        $admin = $this->app->admins()->findById((string) ($session['adminId'] ?? ''));
        if ($admin === null) {
            // The account was removed while the session was live.
            $this->app->sessions()->revoke($token, 'account-gone');

            return;
        }

        unset($admin['passwordHash']);
        $this->admin = $admin;
        $this->token = $token;
    }

    /** @return array<string,mixed>|null */
    public function admin(): ?array
    {
        $this->resolve();

        return $this->admin;
    }

    public function isSignedIn(): bool
    {
        return $this->admin() !== null;
    }

    public function sessionToken(): ?string
    {
        $this->resolve();

        return $this->token;
    }

    public function csrfToken(): string
    {
        $token = $this->sessionToken();

        return $token === null ? '' : Auth::csrfToken($token);
    }

    /**
     * Redirect to sign-in unless there is a live session.
     *
     * Returns null when the request may proceed.
     */
    public function require(Request $request): ?Response
    {
        if ($this->isSignedIn()) {
            return null;
        }

        if (self::wantsJson($request)) {
            return Response::json(['ok' => false, 'error' => 'unauthorised'], 401);
        }

        // Not provisioned yet: send them to setup instead of a login form they
        // cannot possibly satisfy.
        if (!$this->app->admins()->isProvisioned()) {
            return Response::redirect('/admin/setup');
        }

        $next = $request->path !== '' && $request->path !== '/admin'
            ? '?next=' . rawurlencode($request->path)
            : '';

        return Response::redirect('/admin/login' . $next);
    }

    /**
     * Verify the CSRF token on a state-changing request.
     *
     * Returns null when the token is good.
     */
    public function requireCsrf(Request $request): ?Response
    {
        $token = $this->sessionToken();
        $presented = (string) ($request->body[Auth::CSRF_FIELD] ?? '');

        if ($token !== null && Auth::checkCsrf($token, $presented)) {
            return null;
        }

        $this->app->audit()->log(
            'CSRF_REJECTED',
            $this->admin(),
            $request->path,
            'A state-changing request arrived without a valid token.'
        );

        return self::wantsJson($request)
            ? Response::json(['ok' => false, 'error' => 'csrf'], 419)
            : Response::text('Invalid or expired form token. Reload the page and try again.', 419);
    }

    public static function wantsJson(Request $request): bool
    {
        $accept = (string) ($_SERVER['HTTP_ACCEPT'] ?? '');
        $requestedWith = (string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '');

        return str_contains($accept, 'application/json') || $requestedWith === 'fetch';
    }

    /** Set or clear the session cookie. */
    public static function setCookie(?string $token, bool $secure): void
    {
        if (headers_sent()) {
            return;
        }

        $options = [
            'expires' => $token === null ? time() - 3600 : time() + Auth::SESSION_HOURS * 3600,
            'path' => '/admin',
            'secure' => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ];

        setcookie(Auth::SESSION_COOKIE, $token ?? '', $options);
    }
}

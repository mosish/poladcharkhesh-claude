<?php

declare(strict_types=1);

namespace App\Http\Admin;

use App\Core\App;
use App\Core\Request;
use App\Core\Response;
use App\Domain\Families;
use App\Domain\Product;
use App\Support\ImageIntake;

/**
 * Product administration.
 *
 * This controller manages images and nothing else. That is deliberate: an
 * image operation has no reason to be able to write a load rating, and the
 * safest way to guarantee it cannot is for the code path not to exist.
 * Specification editing arrives with its own controller and its own
 * validation.
 *
 * Every action works as a plain form post. The client script upgrades them to
 * background requests, but nothing here depends on it.
 */
final class ProductController
{
    private const PER_PAGE = 24;

    public function __construct(
        private readonly App $app,
        private readonly Guard $guard,
    ) {
    }

    // ------------------------------------------------------------------- list

    public function index(Request $request): Response
    {
        if ($denied = $this->guard->require($request)) {
            return $denied;
        }

        $query = $request->queryString('q');
        $family = $request->queryString('family');
        $missing = $request->queryString('missing') === '1';

        $products = $this->app->products()->search([
            'q' => $query,
            'family' => $family,
        ]);

        $media = $this->app->media();

        if ($missing) {
            $products = array_values(array_filter(
                $products,
                static fn (Product $p): bool => $media->firstUsable($p->gallery()) === null
            ));
        }

        $page = max(1, (int) $request->queryString('page', '1'));
        $total = count($products);
        $pages = max(1, (int) ceil($total / self::PER_PAGE));
        $page = min($page, $pages);
        $slice = array_slice($products, ($page - 1) * self::PER_PAGE, self::PER_PAGE);

        $withoutImages = count(array_filter(
            $this->app->products()->all(),
            static fn (Product $p): bool => $media->firstUsable($p->gallery()) === null
        ));

        return $this->render('admin/products', [
            'title' => 'Products',
            'products' => $slice,
            'total' => $total,
            'page' => $page,
            'pages' => $pages,
            'query' => $query,
            'family' => $family,
            'missing' => $missing,
            'families' => $this->app->products()->familyCounts(),
            'withoutImages' => $withoutImages,
        ]);
    }

    // ------------------------------------------------------------------- edit

    public function edit(Request $request, array $params): Response
    {
        if ($denied = $this->guard->require($request)) {
            return $denied;
        }

        $product = $this->app->products()->findBySlug((string) ($params['slug'] ?? ''), true);
        if ($product === null) {
            return $this->notFound();
        }

        return $this->render('admin/product-media', [
            'title' => $product->designation(),
            'product' => $product,
            'images' => $this->describeImages($product),
            'limitBytes' => ImageIntake::effectiveLimitBytes(),
            'notice' => $request->queryString('done'),
            'problem' => $request->queryString('problem'),
        ]);
    }

    // ----------------------------------------------------------------- upload

    public function upload(Request $request, array $params): Response
    {
        if ($denied = $this->guard->require($request)) {
            return $denied;
        }
        if ($csrf = $this->guard->requireCsrf($request)) {
            return $csrf;
        }

        $product = $this->app->products()->findBySlug((string) ($params['slug'] ?? ''), true);
        if ($product === null) {
            return $this->notFound();
        }

        $files = self::normaliseFiles($_FILES['images'] ?? null);
        if ($files === []) {
            return $this->reject($request, $product->slug, 'noFile');
        }

        $accepted = [];
        $rejected = [];

        foreach ($files as $file) {
            $result = $this->app->images()->accept($file, $product->slug);
            if ($result['ok'] === true) {
                $image = $result['image'];
                $url = (string) $image['url'];
                $this->app->media()->register($url, $image + ['productSlug' => $product->slug]);
                $accepted[] = $url;
            } else {
                $rejected[] = $result['reason'];
            }
        }

        if ($accepted !== []) {
            $existing = $product->gallery();

            // New images normally go to the end, leaving the chosen primary
            // alone. But when the current primary cannot be displayed — which
            // is every imported reference until it is replaced — the first
            // working upload takes its place, so the catalogue stops showing a
            // fallback the moment there is something real to show.
            $primaryWorks = $existing !== [] && $this->app->media()->isUsable($existing[0]);
            $gallery = $primaryWorks
                ? array_merge($existing, $accepted)
                : array_merge($accepted, $existing);

            $gallery = array_values(array_unique($gallery));

            $this->app->products()->updateImages(
                $product->slug,
                $gallery,
                (string) ($this->guard->admin()['username'] ?? 'admin')
            );

            $this->app->audit()->log(
                'MEDIA_UPLOADED',
                $this->guard->admin(),
                $product->slug,
                sprintf('%d image(s) added to %s.', count($accepted), $product->designation()),
                ['added' => $accepted, 'rejected' => $rejected]
            );
        } elseif ($rejected !== []) {
            $this->app->audit()->log(
                'MEDIA_REJECTED',
                $this->guard->admin(),
                $product->slug,
                sprintf('%d upload(s) refused.', count($rejected)),
                ['reasons' => $rejected]
            );
        }

        if (Guard::wantsJson($request)) {
            return Response::json([
                'ok' => $accepted !== [],
                'added' => $accepted,
                'rejected' => $rejected,
                'images' => $this->describeImages(
                    $this->app->products()->findBySlug($product->slug, true) ?? $product
                ),
            ], $accepted !== [] ? 200 : 422);
        }

        return $this->back($product->slug, $accepted !== []
            ? ['done' => 'uploaded']
            : ['problem' => $rejected[0] ?? 'failed']);
    }

    // ---------------------------------------------------------------- primary

    public function setPrimary(Request $request, array $params): Response
    {
        if ($denied = $this->guard->require($request)) {
            return $denied;
        }
        if ($csrf = $this->guard->requireCsrf($request)) {
            return $csrf;
        }

        $product = $this->app->products()->findBySlug((string) ($params['slug'] ?? ''), true);
        if ($product === null) {
            return $this->notFound();
        }

        $target = (string) ($request->body['url'] ?? '');
        $gallery = $product->gallery();
        if (!in_array($target, $gallery, true)) {
            return $this->reject($request, $product->slug, 'unknownImage');
        }

        $reordered = array_merge(
            [$target],
            array_values(array_filter($gallery, static fn (string $url): bool => $url !== $target))
        );

        $this->app->products()->updateImages(
            $product->slug,
            $reordered,
            (string) ($this->guard->admin()['username'] ?? 'admin')
        );

        $this->app->audit()->log(
            'PRODUCT_UPDATED',
            $this->guard->admin(),
            $product->slug,
            sprintf('Primary image changed for %s.', $product->designation()),
            ['primary' => $target]
        );

        if (Guard::wantsJson($request)) {
            return Response::json([
                'ok' => true,
                'images' => $this->describeImages(
                    $this->app->products()->findBySlug($product->slug, true) ?? $product
                ),
            ]);
        }

        return $this->back($product->slug, ['done' => 'primary']);
    }

    // ----------------------------------------------------------------- delete

    public function deleteImage(Request $request, array $params): Response
    {
        if ($denied = $this->guard->require($request)) {
            return $denied;
        }
        if ($csrf = $this->guard->requireCsrf($request)) {
            return $csrf;
        }

        $product = $this->app->products()->findBySlug((string) ($params['slug'] ?? ''), true);
        if ($product === null) {
            return $this->notFound();
        }

        $target = (string) ($request->body['url'] ?? '');
        $gallery = $product->gallery();
        if (!in_array($target, $gallery, true)) {
            return $this->reject($request, $product->slug, 'unknownImage');
        }

        $remaining = array_values(array_filter($gallery, static fn (string $url): bool => $url !== $target));
        $this->app->products()->updateImages(
            $product->slug,
            $remaining,
            (string) ($this->guard->admin()['username'] ?? 'admin')
        );

        // Only files this application created are removed from disk. An
        // imported path is detached from the product but left alone, because
        // it may still be referenced elsewhere and is not ours to delete.
        $meta = $this->app->media()->meta($target);
        if ($meta !== null) {
            $this->app->images()->remove($target, (string) ($meta['thumbnail'] ?? ''));
            $this->app->media()->forget($target);
        }

        $this->app->audit()->log(
            'MEDIA_DELETED',
            $this->guard->admin(),
            $product->slug,
            sprintf('Image removed from %s.', $product->designation()),
            ['removed' => $target, 'fileDeleted' => $meta !== null]
        );

        if (Guard::wantsJson($request)) {
            return Response::json([
                'ok' => true,
                'images' => $this->describeImages(
                    $this->app->products()->findBySlug($product->slug, true) ?? $product
                ),
            ]);
        }

        return $this->back($product->slug, ['done' => 'deleted']);
    }

    // ------------------------------------------------------------------ utils

    /**
     * Describe a product's images for the editor and the JSON responses.
     *
     * `usable` distinguishes an image the server has verified from an imported
     * path that cannot be decoded — the editor shows the difference rather
     * than rendering a broken thumbnail.
     *
     * @return list<array<string,mixed>>
     */
    private function describeImages(Product $product): array
    {
        $media = $this->app->media();
        $out = [];

        foreach ($product->gallery() as $index => $url) {
            $meta = $media->meta($url);
            $out[] = [
                'url' => $url,
                'thumbnail' => $media->thumbnail($url),
                'primary' => $index === 0,
                'usable' => $media->isUsable($url),
                'managed' => $meta !== null,
                'width' => $meta['width'] ?? null,
                'height' => $meta['height'] ?? null,
                'bytes' => $meta['bytes'] ?? null,
                'originalName' => $meta['originalName'] ?? null,
                'uploadedAt' => $meta['uploadedAt'] ?? null,
            ];
        }

        return $out;
    }

    /**
     * Normalise the two shapes PHP uses for `<input type="file" multiple>`.
     *
     * @return list<array<string,mixed>>
     */
    private static function normaliseFiles(mixed $input): array
    {
        if (!is_array($input) || !isset($input['name'])) {
            return [];
        }

        if (!is_array($input['name'])) {
            return ($input['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE ? [] : [$input];
        }

        $files = [];
        foreach (array_keys($input['name']) as $index) {
            if (($input['error'][$index] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
                continue;
            }
            $files[] = [
                'name' => $input['name'][$index] ?? '',
                'type' => $input['type'][$index] ?? '',
                'tmp_name' => $input['tmp_name'][$index] ?? '',
                'error' => $input['error'][$index] ?? UPLOAD_ERR_NO_FILE,
                'size' => $input['size'][$index] ?? 0,
            ];
        }

        return array_slice($files, 0, 12);
    }

    /** @param array<string,string> $query */
    private function back(string $slug, array $query): Response
    {
        return Response::redirect('/admin/products/' . rawurlencode($slug) . '?' . http_build_query($query));
    }

    /**
     * Refuse an action, answering in the shape the caller asked for.
     *
     * A background request gets JSON it can read; a plain form post gets a
     * redirect back to the editor with the reason in the query string. Sending
     * a redirect to a fetch caller would look like an empty success.
     */
    private function reject(Request $request, string $slug, string $reason): Response
    {
        if (Guard::wantsJson($request)) {
            return Response::json(['ok' => false, 'error' => $reason], 422);
        }

        return $this->back($slug, ['problem' => $reason]);
    }

    private function notFound(): Response
    {
        return $this->render('admin/message', [
            'title' => 'Not found',
            'heading' => 'That product does not exist',
            'message' => 'It may have been removed, or the address may be mistyped.',
        ], 404);
    }

    /** @param array<string,mixed> $data */
    private function render(string $template, array $data, int $status = 200): Response
    {
        return Response::html(
            $this->app->view()->page($template, $data + [
                'guard' => $this->guard,
                'admin' => $this->guard->admin(),
                'csrf' => $this->guard->csrfToken(),
            ], 'admin/layout'),
            $status
        );
    }
}

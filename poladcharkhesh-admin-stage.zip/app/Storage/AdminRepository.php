<?php

declare(strict_types=1);

namespace App\Storage;

use App\Support\Auth;

/**
 * Administrator accounts.
 *
 * There are no shipped credentials. The first account is created through the
 * setup route, which is only reachable while no account exists — so a fresh
 * deployment has exactly one window in which an account can be made without
 * signing in, and it closes the moment someone uses it.
 */
final class AdminRepository
{
    public function __construct(private readonly JsonStore $store)
    {
    }

    /** @return list<array<string,mixed>> */
    public function all(): array
    {
        $rows = $this->store->read('admins', []);

        return array_values(array_filter($rows, 'is_array'));
    }

    public function isProvisioned(): bool
    {
        return $this->all() !== [];
    }

    /** @return array<string,mixed>|null */
    public function findByUsername(string $username): ?array
    {
        $needle = mb_strtolower(trim($username), 'UTF-8');
        foreach ($this->all() as $admin) {
            if (mb_strtolower((string) ($admin['username'] ?? ''), 'UTF-8') === $needle) {
                return $admin;
            }
        }

        return null;
    }

    /** @return array<string,mixed>|null */
    public function findById(string $id): ?array
    {
        foreach ($this->all() as $admin) {
            if (($admin['id'] ?? null) === $id) {
                return $admin;
            }
        }

        return null;
    }

    /**
     * Create the first administrator.
     *
     * @return array<string,mixed> the created record, without the hash
     */
    public function createFirst(string $username, string $password, string $name, string $email): array
    {
        if ($this->isProvisioned()) {
            throw new \RuntimeException('An administrator already exists.');
        }

        $now = gmdate('c');
        $record = [
            'id' => Auth::id('adm'),
            'username' => trim($username),
            'name' => trim($name),
            'email' => trim($email),
            'role' => 'superadmin',
            'passwordHash' => Auth::hashPassword($password),
            'createdAt' => $now,
            'passwordChangedAt' => $now,
            'lastLoginAt' => null,
        ];

        $this->store->mutate('admins', static function (array $current) use ($record): array {
            // Re-checked under the lock: two simultaneous setup requests must
            // not both succeed.
            if (array_filter($current, 'is_array') !== []) {
                throw new \RuntimeException('An administrator already exists.');
            }
            $current[] = $record;

            return $current;
        }, []);

        unset($record['passwordHash']);

        return $record;
    }

    public function recordLogin(string $id): void
    {
        $now = gmdate('c');
        $this->store->mutate('admins', static function (array $current) use ($id, $now): array {
            foreach ($current as $index => $admin) {
                if (is_array($admin) && ($admin['id'] ?? null) === $id) {
                    $current[$index]['lastLoginAt'] = $now;
                }
            }

            return $current;
        }, []);
    }

    public function updatePasswordHash(string $id, string $hash): void
    {
        $now = gmdate('c');
        $this->store->mutate('admins', static function (array $current) use ($id, $hash, $now): array {
            foreach ($current as $index => $admin) {
                if (is_array($admin) && ($admin['id'] ?? null) === $id) {
                    $current[$index]['passwordHash'] = $hash;
                    $current[$index]['passwordChangedAt'] = $now;
                }
            }

            return $current;
        }, []);
    }
}

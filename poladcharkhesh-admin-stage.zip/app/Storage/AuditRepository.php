<?php

declare(strict_types=1);

namespace App\Storage;

use App\Support\Auth;

/**
 * The record of what administrators did.
 *
 * Entries are append-only from the application's point of view — nothing in
 * the admin panel edits or deletes them. Passwords, tokens, cookies and
 * secrets are never written here; the `before`/`after` payloads are filtered
 * against a denylist on the way in rather than relying on every call site to
 * remember.
 */
final class AuditRepository
{
    /** Field names that must never reach the log, whatever a caller passes. */
    private const REDACT = [
        'password', 'passwordhash', 'password_hash', 'newpassword', 'currentpassword',
        'token', 'sessiontoken', 'csrf', '_token', 'cookie', 'secret', 'authorization',
    ];

    private const MAX_ENTRIES = 5000;

    public function __construct(private readonly JsonStore $store)
    {
    }

    /** @return list<array<string,mixed>> */
    public function all(): array
    {
        $rows = $this->store->read('audit', []);

        return array_values(array_filter($rows, 'is_array'));
    }

    /**
     * Most recent first.
     *
     * @return list<array<string,mixed>>
     */
    public function recent(int $limit = 100): array
    {
        $entries = $this->all();
        usort($entries, static fn (array $a, array $b): int =>
            strcmp((string) ($b['at'] ?? ''), (string) ($a['at'] ?? '')));

        return array_slice($entries, 0, $limit);
    }

    /**
     * @param array<string,mixed> $context
     */
    public function log(string $action, ?array $actor, string $target = '', string $summary = '', array $context = []): void
    {
        $entry = array_filter([
            'id' => Auth::id('log'),
            'action' => $action,
            'at' => gmdate('c'),
            'by' => $actor === null ? 'anonymous' : (string) ($actor['username'] ?? $actor['id'] ?? 'unknown'),
            'actorId' => $actor === null ? null : (string) ($actor['id'] ?? ''),
            'target' => $target,
            'summary' => $summary,
            'context' => self::scrub($context),
        ], static fn ($value): bool => $value !== null && $value !== '' && $value !== []);

        $this->store->mutate('audit', static function (array $current) use ($entry): array {
            $current[] = $entry;
            if (count($current) > self::MAX_ENTRIES) {
                $current = array_slice($current, -self::MAX_ENTRIES);
            }

            return array_values($current);
        }, []);
    }

    /**
     * Remove anything secret-shaped, at any depth.
     *
     * @param array<mixed> $data
     * @return array<mixed>
     */
    private static function scrub(array $data): array
    {
        $out = [];
        foreach ($data as $key => $value) {
            $name = is_string($key) ? str_replace(['-', ' '], '', mb_strtolower($key, 'UTF-8')) : '';
            if ($name !== '' && in_array($name, self::REDACT, true)) {
                continue;
            }
            if (is_array($value)) {
                $out[$key] = self::scrub($value);
            } elseif (is_scalar($value) || $value === null) {
                $out[$key] = is_string($value) ? mb_substr($value, 0, 500, 'UTF-8') : $value;
            }
        }

        return $out;
    }
}

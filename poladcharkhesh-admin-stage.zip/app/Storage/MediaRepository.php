<?php

declare(strict_types=1);

namespace App\Storage;

/**
 * The registry of assets that are actually usable.
 *
 * Two things feed it:
 *
 *  - `scripts/audit_assets.py` decodes every file the catalogue references and
 *    records which ones survive. It exists because a file can be present,
 *    serve with the right MIME type, and still be undecodable — which is the
 *    state the entire imported product photography is in.
 *  - The admin panel registers every image it accepts. Those are decoded and
 *    re-encoded on the way in, so an entry here is a file that has provably
 *    been read as an image by this server.
 *
 * The interface asks this before rendering an image. When nothing usable
 * exists for a product, the card falls back to the family's technical
 * schematic — deliberate over the alternatives, since a broken image reads as
 * neglect and a stock photograph would show a part the company is not selling.
 */
final class MediaRepository
{
    /** @var array<string,true>|null */
    private ?array $usable = null;

    public function __construct(private readonly JsonStore $store)
    {
    }

    /** @return array<string,mixed> */
    private function registry(): array
    {
        /** @var array<string,mixed> $registry */
        $registry = $this->store->read('media', []);

        return $registry;
    }

    public function isUsable(?string $path): bool
    {
        if ($path === null || $path === '') {
            return false;
        }

        if ($this->usable === null) {
            $registry = $this->registry();
            $map = [];

            $audited = $registry['usable'] ?? [];
            if (is_array($audited)) {
                foreach ($audited as $entry) {
                    if (is_string($entry)) {
                        $map[$entry] = true;
                    }
                }
            }

            foreach ($this->uploads() as $upload) {
                $url = $upload['url'] ?? null;
                if (is_string($url) && $url !== '') {
                    $map[$url] = true;
                }
            }

            $this->usable = $map;
        }

        return isset($this->usable[$path]);
    }

    /**
     * The first usable image from a candidate list, or null.
     *
     * @param list<string> $candidates
     */
    public function firstUsable(array $candidates): ?string
    {
        foreach ($candidates as $candidate) {
            if ($this->isUsable($candidate)) {
                return $candidate;
            }
        }

        return null;
    }

    /**
     * The card-sized variant of an image, when one was generated for it.
     *
     * Uploads carry a thumbnail; imported files do not, and fall back to the
     * full image.
     */
    public function thumbnail(string $url): string
    {
        $meta = $this->meta($url);
        $thumb = $meta['thumbnail'] ?? null;

        return is_string($thumb) && $thumb !== '' ? $thumb : $url;
    }

    /** @return array<string,mixed>|null */
    public function meta(string $url): ?array
    {
        foreach ($this->uploads() as $upload) {
            if (($upload['url'] ?? null) === $url) {
                return $upload;
            }
        }

        return null;
    }

    /**
     * Record an accepted upload.
     *
     * @param array<string,mixed> $meta
     */
    public function register(string $url, array $meta): void
    {
        $record = ['url' => $url] + $meta;

        $this->store->mutate('media', static function (array $current) use ($url, $record): array {
            $uploads = is_array($current['uploads'] ?? null) ? $current['uploads'] : [];
            $uploads = array_values(array_filter(
                $uploads,
                static fn ($entry): bool => is_array($entry) && ($entry['url'] ?? null) !== $url
            ));
            $uploads[] = $record;
            $current['uploads'] = $uploads;

            return $current;
        }, []);

        $this->usable = null;
    }

    public function forget(string $url): void
    {
        $this->store->mutate('media', static function (array $current) use ($url): array {
            $uploads = is_array($current['uploads'] ?? null) ? $current['uploads'] : [];
            $current['uploads'] = array_values(array_filter(
                $uploads,
                static fn ($entry): bool => is_array($entry) && ($entry['url'] ?? null) !== $url
            ));

            return $current;
        }, []);

        $this->usable = null;
    }

    /** @return list<array<string,mixed>> */
    public function uploads(): array
    {
        $uploads = $this->registry()['uploads'] ?? [];
        if (!is_array($uploads)) {
            return [];
        }

        return array_values(array_filter(
            $uploads,
            static fn ($entry): bool => is_array($entry) && is_string($entry['url'] ?? null)
        ));
    }

    /** @return list<array<string,mixed>> */
    public function broken(): array
    {
        $broken = $this->registry()['broken'] ?? [];

        return is_array($broken) ? array_values(array_filter($broken, 'is_array')) : [];
    }
}

<?php

declare(strict_types=1);

namespace App\Storage;

/**
 * Site-wide SEO defaults and the canonical domain configuration.
 */
final class SeoRepository extends DocumentRepository
{
    protected function collection(): string
    {
        return 'seo';
    }

    /** @return array<string,mixed> */
    protected function defaults(): array
    {
        return [
            'defaultTitleFa' => '', 'defaultTitleEn' => '',
            'defaultDescriptionFa' => '', 'defaultDescriptionEn' => '',
            'keywordsFa' => [], 'keywordsEn' => [],
            'organizationNameFa' => '', 'organizationNameEn' => '',
            'ogImageUrl' => '',
            'googleSiteVerification' => '',
            // The Persian site is served from the .ir domain and the English
            // site from .com. Canonicals are built from these, never from the
            // request host, so a development hostname can never be published as
            // a canonical URL.
            'canonicalHostFa' => 'poladcharkhesh.ir',
            'canonicalHostEn' => 'poladcharkhesh.com',
            // The organisation's own address. Both domains serve the site, but
            // one of them is the company's public identity: it is what the
            // Organization record points at, and what search engines are told
            // to prefer when nothing else distinguishes the two.
            'primaryHost' => 'poladcharkhesh.com',
        ];
    }

    public function canonicalHost(string $language): string
    {
        return $this->value($language === 'fa' ? 'canonicalHostFa' : 'canonicalHostEn');
    }

    public function primaryHost(): string
    {
        return $this->value('primaryHost', $this->value('canonicalHostEn'));
    }

    /**
     * Every host the site is published on, for `sameAs`.
     *
     * @return list<string>
     */
    public function allHosts(): array
    {
        $hosts = array_filter([
            $this->value('canonicalHostEn'),
            $this->value('canonicalHostFa'),
        ]);

        return array_values(array_unique($hosts));
    }

    public function defaultTitle(string $language): string
    {
        return $this->value($language === 'fa' ? 'defaultTitleFa' : 'defaultTitleEn');
    }

    public function defaultDescription(string $language): string
    {
        return $this->value($language === 'fa' ? 'defaultDescriptionFa' : 'defaultDescriptionEn');
    }

    /** @return list<string> */
    public function keywords(string $language): array
    {
        $value = $this->get()[$language === 'fa' ? 'keywordsFa' : 'keywordsEn'] ?? [];

        return is_array($value) ? array_values(array_filter($value, 'is_string')) : [];
    }
}

<?php

declare(strict_types=1);

namespace App\Storage;

use App\Support\Auth;

/**
 * Server-side admin sessions.
 *
 * The cookie carries a token; the store holds only its SHA-256 digest. A copy
 * of the data store therefore cannot be replayed as a live session.
 *
 * Sessions expire two ways — an absolute lifetime from creation and an idle
 * timeout since the last request — and can be revoked individually or all at
 * once, which is what a password change does.
 */
final class SessionRepository
{
    public function __construct(private readonly JsonStore $store)
    {
    }

    /** @return list<array<string,mixed>> */
    public function all(): array
    {
        $rows = $this->store->read('sessions', []);

        return array_values(array_filter($rows, 'is_array'));
    }

    /**
     * Start a session and return the token to put in the cookie.
     *
     * The token is returned once and never stored, so it cannot be recovered
     * from the store afterwards.
     */
    public function create(string $adminId, string $ip, string $userAgent): string
    {
        $token = Auth::newToken();
        $now = time();

        $record = [
            'id' => Auth::digest($token),
            'adminId' => $adminId,
            'createdAt' => gmdate('c', $now),
            'expiresAt' => gmdate('c', $now + Auth::SESSION_HOURS * 3600),
            'lastActiveAt' => gmdate('c', $now),
            'ip' => $ip,
            'userAgent' => mb_substr($userAgent, 0, 200, 'UTF-8'),
            'revoked' => false,
        ];

        $this->store->mutate('sessions', static function (array $current) use ($record): array {
            $current = self::prune($current);
            $current[] = $record;

            return $current;
        }, []);

        return $token;
    }

    /**
     * Resolve a token to a live session, refreshing its activity timestamp.
     *
     * @return array<string,mixed>|null
     */
    public function resolve(string $token): ?array
    {
        if ($token === '') {
            return null;
        }

        $id = Auth::digest($token);
        $now = time();
        $found = null;

        $this->store->mutate('sessions', static function (array $current) use ($id, $now, &$found): array {
            foreach ($current as $index => $session) {
                if (!is_array($session) || ($session['id'] ?? null) !== $id) {
                    continue;
                }
                if (($session['revoked'] ?? false) === true) {
                    return $current;
                }
                if (strtotime((string) ($session['expiresAt'] ?? '')) < $now) {
                    return $current;
                }
                $lastActive = strtotime((string) ($session['lastActiveAt'] ?? ''));
                if ($lastActive !== false && $now - $lastActive > Auth::IDLE_MINUTES * 60) {
                    $current[$index]['revoked'] = true;
                    $current[$index]['revokedReason'] = 'idle';

                    return $current;
                }

                $current[$index]['lastActiveAt'] = gmdate('c', $now);
                $found = $current[$index];

                return $current;
            }

            return $current;
        }, []);

        return $found;
    }

    public function revoke(string $token, string $reason = 'logout'): void
    {
        $id = Auth::digest($token);
        $this->store->mutate('sessions', static function (array $current) use ($id, $reason): array {
            foreach ($current as $index => $session) {
                if (is_array($session) && ($session['id'] ?? null) === $id) {
                    $current[$index]['revoked'] = true;
                    $current[$index]['revokedReason'] = $reason;
                }
            }

            return self::prune($current);
        }, []);
    }

    /** Revoke every session for an administrator — used on password change. */
    public function revokeAllFor(string $adminId, string $reason = 'password-changed'): int
    {
        $count = 0;
        $this->store->mutate('sessions', static function (array $current) use ($adminId, $reason, &$count): array {
            foreach ($current as $index => $session) {
                if (
                    is_array($session)
                    && ($session['adminId'] ?? null) === $adminId
                    && ($session['revoked'] ?? false) !== true
                ) {
                    $current[$index]['revoked'] = true;
                    $current[$index]['revokedReason'] = $reason;
                    $count++;
                }
            }

            return self::prune($current);
        }, []);

        return $count;
    }

    /**
     * Drop sessions that expired more than a day ago.
     *
     * Recently expired ones are kept briefly so "your session expired" can be
     * distinguished from "that token was never valid".
     *
     * @param array<mixed> $sessions
     * @return list<array<string,mixed>>
     */
    private static function prune(array $sessions): array
    {
        $cutoff = time() - 86400;

        return array_values(array_filter($sessions, static function ($session) use ($cutoff): bool {
            if (!is_array($session)) {
                return false;
            }
            $expires = strtotime((string) ($session['expiresAt'] ?? ''));

            return $expires === false || $expires > $cutoff;
        }));
    }
}

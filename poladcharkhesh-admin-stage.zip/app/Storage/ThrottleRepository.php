<?php

declare(strict_types=1);

namespace App\Storage;

/**
 * Attempt throttling for abuse-prone endpoints.
 *
 * Counters are keyed by a hash rather than the raw value, so the store never
 * holds a list of attempted usernames or a plain log of visitor addresses.
 *
 * Login checks two keys at once: a tight one on the address-and-username pair,
 * which stops a password being guessed, and a looser one on the address alone,
 * which stops one client working through a list of usernames. Locking only on
 * the pair would let the second attack through.
 */
final class ThrottleRepository
{
    public function __construct(private readonly JsonStore $store)
    {
    }

    private static function key(string $scope, string $value): string
    {
        return $scope . ':' . substr(hash('sha256', mb_strtolower($value, 'UTF-8')), 0, 24);
    }

    /**
     * Seconds remaining on a lock, or 0 when the caller may proceed.
     */
    public function lockedFor(string $scope, string $value): int
    {
        $key = self::key($scope, $value);
        $now = time();

        foreach ($this->store->read('throttle', []) as $entry) {
            if (!is_array($entry) || ($entry['key'] ?? null) !== $key) {
                continue;
            }
            $until = (int) ($entry['lockedUntil'] ?? 0);

            return $until > $now ? $until - $now : 0;
        }

        return 0;
    }

    /**
     * Record a failure and lock the key once it passes the limit.
     *
     * @return int seconds of lock now in force, 0 if still under the limit
     */
    public function fail(string $scope, string $value, int $limit, int $windowSeconds, int $lockSeconds): int
    {
        $key = self::key($scope, $value);
        $now = time();
        $lock = 0;

        $this->store->mutate('throttle', static function (array $current) use ($key, $now, $limit, $windowSeconds, $lockSeconds, &$lock): array {
            $current = self::prune($current, $now);

            foreach ($current as $index => $entry) {
                if (!is_array($entry) || ($entry['key'] ?? null) !== $key) {
                    continue;
                }

                $firstAt = (int) ($entry['firstAt'] ?? $now);
                $count = (int) ($entry['count'] ?? 0);

                // A window that has elapsed starts over rather than
                // accumulating failures from hours ago.
                if ($now - $firstAt > $windowSeconds) {
                    $current[$index] = ['key' => $key, 'count' => 1, 'firstAt' => $now, 'lockedUntil' => 0];

                    return $current;
                }

                $count++;
                $current[$index]['count'] = $count;
                if ($count >= $limit) {
                    $lock = $lockSeconds;
                    $current[$index]['lockedUntil'] = $now + $lockSeconds;
                }

                return $current;
            }

            $current[] = ['key' => $key, 'count' => 1, 'firstAt' => $now, 'lockedUntil' => 0];

            return $current;
        }, []);

        return $lock;
    }

    /** Clear a key after a success. */
    public function clear(string $scope, string $value): void
    {
        $key = self::key($scope, $value);
        $now = time();

        $this->store->mutate('throttle', static function (array $current) use ($key, $now): array {
            $current = array_values(array_filter(
                self::prune($current, $now),
                static fn ($entry): bool => is_array($entry) && ($entry['key'] ?? null) !== $key
            ));

            return $current;
        }, []);
    }

    /**
     * @param array<mixed> $entries
     * @return list<array<string,mixed>>
     */
    private static function prune(array $entries, int $now): array
    {
        return array_values(array_filter($entries, static function ($entry) use ($now): bool {
            if (!is_array($entry)) {
                return false;
            }
            $firstAt = (int) ($entry['firstAt'] ?? 0);
            $lockedUntil = (int) ($entry['lockedUntil'] ?? 0);

            return $lockedUntil > $now || $now - $firstAt < 86400;
        }));
    }
}

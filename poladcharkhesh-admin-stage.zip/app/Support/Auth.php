<?php

declare(strict_types=1);

namespace App\Support;

use App\Core\Config;

/**
 * Password hashing and session tokens.
 *
 * Argon2id where the host's PHP provides it, bcrypt otherwise — both through
 * `password_hash`, so the algorithm and its parameters travel inside the hash
 * and an old hash keeps verifying after an upgrade.
 *
 * Session tokens are generated here and only ever stored as a SHA-256 digest.
 * A stolen copy of the data store therefore cannot be used to impersonate a
 * live session, which matters more than usual when the store is a set of files
 * on shared hosting.
 */
final class Auth
{
    public const SESSION_COOKIE = 'pc_admin';
    public const CSRF_FIELD = '_token';

    /** Sessions expire this many hours after creation. */
    public const SESSION_HOURS = 12;

    /** Idle sessions expire this many minutes after the last request. */
    public const IDLE_MINUTES = 90;

    public static function hashPassword(string $password): string
    {
        $algorithm = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;

        $options = $algorithm === PASSWORD_BCRYPT
            ? ['cost' => 12]
            : ['memory_cost' => 65536, 'time_cost' => 4, 'threads' => 2];

        $hash = password_hash($password, $algorithm, $options);
        if (!is_string($hash) || $hash === '') {
            throw new \RuntimeException('Password hashing failed.');
        }

        return $hash;
    }

    public static function verifyPassword(string $password, string $hash): bool
    {
        return $hash !== '' && password_verify($password, $hash);
    }

    /** True when the stored hash was made with weaker parameters than current. */
    public static function needsRehash(string $hash): bool
    {
        $algorithm = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;

        return password_needs_rehash($hash, $algorithm);
    }

    /**
     * Assess a password.
     *
     * Length carries most of the strength, so the rule is a real minimum rather
     * than a character-class obstacle course. Common passwords are refused
     * outright: a twelve-character password that appears on every wordlist is
     * not twelve characters of entropy.
     *
     * @return list<string> the reasons it is unacceptable, empty when it is fine
     */
    public static function passwordProblems(string $password, string $username = ''): array
    {
        $problems = [];
        $length = mb_strlen($password, 'UTF-8');

        if ($length < 12) {
            $problems[] = 'tooShort';
        }
        if ($length > 4096) {
            $problems[] = 'tooLong';
        }
        if (trim($password) === '') {
            $problems[] = 'blank';
        }

        $lower = mb_strtolower($password, 'UTF-8');
        $banned = [
            'password', 'admin', '123456', '12345678', '123456789', 'qwerty',
            'letmein', 'welcome', 'iloveyou', 'admin123', 'password123',
            'poladcharkhesh', 'bearing', 'polad',
        ];
        foreach ($banned as $word) {
            if (str_contains($lower, $word)) {
                $problems[] = 'common';
                break;
            }
        }

        if ($username !== '' && str_contains($lower, mb_strtolower($username, 'UTF-8'))) {
            $problems[] = 'containsUsername';
        }

        return array_values(array_unique($problems));
    }

    /** A high-entropy session token. Returned once; only its digest is stored. */
    public static function newToken(): string
    {
        return bin2hex(random_bytes(32));
    }

    public static function digest(string $token): string
    {
        return hash('sha256', $token);
    }

    /** Constant-time comparison, for CSRF tokens and the like. */
    public static function equals(string $a, string $b): bool
    {
        return hash_equals($a, $b);
    }

    /**
     * The CSRF token for a session.
     *
     * Derived from the session token and the cookie secret rather than stored,
     * so it needs no extra state and is invalidated automatically when the
     * session ends.
     */
    public static function csrfToken(string $sessionToken): string
    {
        $secret = Config::get('APP_COOKIE_SECRET', 'development-cookie-secret') ?? '';

        return hash_hmac('sha256', 'csrf:' . $sessionToken, $secret);
    }

    public static function checkCsrf(string $sessionToken, string $presented): bool
    {
        return $presented !== '' && self::equals(self::csrfToken($sessionToken), $presented);
    }

    public static function id(string $prefix): string
    {
        return $prefix . '_' . bin2hex(random_bytes(9));
    }
}

<?php

declare(strict_types=1);

namespace App\Support;

/**
 * Turning an uploaded file into a product image.
 *
 * The rule here is that nothing is trusted about the upload — not its
 * extension, not the `Content-Type` the browser claimed, not the filename.
 * Every file is decoded with GD and re-encoded before it is stored.
 *
 * Re-encoding does four jobs at once:
 *
 *  1. **It proves the file is an image.** If GD cannot decode it, it does not
 *     get stored. This is the check the project needs most: the entire
 *     imported catalogue was files that looked like images to the filesystem,
 *     served with the right MIME type, and could not be decoded by anything.
 *  2. **It removes anything smuggled inside.** A polyglot file with PHP in its
 *     metadata does not survive being decoded to a pixel buffer and written
 *     out again.
 *  3. **It strips EXIF**, including the GPS tags phone cameras attach.
 *  4. **It normalises format and size**, so the catalogue is consistent and a
 *     4 MB phone photo does not become a 4 MB page weight.
 *
 * Two sizes are written: a full view capped at 1600 px and a card thumbnail at
 * 640 px. Filenames come from the content hash, so the same photograph
 * uploaded twice does not accumulate copies, and a filename can never carry a
 * path or an extension chosen by the uploader.
 */
final class ImageIntake
{
    public const MAX_BYTES = 10 * 1024 * 1024;
    public const MAX_EDGE = 1600;
    public const THUMB_EDGE = 640;

    /** Minimum useful size — smaller than this is a favicon, not a product photo. */
    public const MIN_EDGE = 200;

    private const ACCEPTED = [
        IMAGETYPE_JPEG => 'jpeg',
        IMAGETYPE_PNG => 'png',
        IMAGETYPE_WEBP => 'webp',
        IMAGETYPE_GIF => 'gif',
        IMAGETYPE_AVIF => 'avif',
    ];

    public function __construct(private readonly string $publicPath)
    {
    }

    /**
     * Process one uploaded file.
     *
     * @param array<string,mixed> $file one entry from $_FILES
     * @return array{ok:true,image:array<string,mixed>}|array{ok:false,reason:string,detail?:string}
     */
    public function accept(array $file, string $productSlug): array
    {
        $error = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($error !== UPLOAD_ERR_OK) {
            return ['ok' => false, 'reason' => self::uploadErrorReason($error)];
        }

        $tmp = (string) ($file['tmp_name'] ?? '');
        // is_uploaded_file is what distinguishes a real upload from a path a
        // request tried to point us at.
        if ($tmp === '' || !is_uploaded_file($tmp)) {
            return ['ok' => false, 'reason' => 'notAnUpload'];
        }

        $size = (int) ($file['size'] ?? 0);
        if ($size <= 0) {
            return ['ok' => false, 'reason' => 'empty'];
        }
        if ($size > self::MAX_BYTES) {
            return ['ok' => false, 'reason' => 'tooLarge'];
        }

        // Type comes from the file's own bytes. The client-supplied type and
        // the extension are both ignored.
        $info = @getimagesize($tmp);
        if ($info === false || !isset(self::ACCEPTED[$info[2]])) {
            return ['ok' => false, 'reason' => 'notAnImage'];
        }

        [$width, $height, $type] = $info;
        if ($width < self::MIN_EDGE && $height < self::MIN_EDGE) {
            return ['ok' => false, 'reason' => 'tooSmall'];
        }

        // A very large pixel count can exhaust memory during decode regardless
        // of how small the compressed file is.
        if ($width * $height > 40_000_000) {
            return ['ok' => false, 'reason' => 'tooManyPixels'];
        }

        $source = self::decode($tmp, $type);
        if ($source === null) {
            return ['ok' => false, 'reason' => 'undecodable'];
        }

        try {
            $slug = self::safeSlug($productSlug);
            $directory = $this->publicPath . '/assets/uploads/products/' . $slug;
            if (!is_dir($directory) && !mkdir($directory, 0o755, true) && !is_dir($directory)) {
                return ['ok' => false, 'reason' => 'notWritable'];
            }

            $full = self::fit($source, self::MAX_EDGE);
            $thumb = self::fit($source, self::THUMB_EDGE);

            $hash = substr(hash_file('sha256', $tmp) ?: bin2hex(random_bytes(8)), 0, 16);
            $extension = function_exists('imagewebp') ? 'webp' : 'jpg';

            $fullName = $hash . '.' . $extension;
            $thumbName = $hash . '-card.' . $extension;

            if (
                !self::encode($full, $directory . '/' . $fullName, $extension)
                || !self::encode($thumb, $directory . '/' . $thumbName, $extension)
            ) {
                return ['ok' => false, 'reason' => 'encodeFailed'];
            }

            $url = '/assets/uploads/products/' . $slug . '/' . $fullName;
            $thumbUrl = '/assets/uploads/products/' . $slug . '/' . $thumbName;

            return ['ok' => true, 'image' => [
                'url' => $url,
                'thumbnail' => $thumbUrl,
                'width' => imagesx($full),
                'height' => imagesy($full),
                'bytes' => (int) (filesize($directory . '/' . $fullName) ?: 0),
                'format' => $extension,
                'sourceFormat' => self::ACCEPTED[$type],
                'originalName' => self::displayName((string) ($file['name'] ?? '')),
                'uploadedAt' => gmdate('c'),
            ]];
        } finally {
            imagedestroy($source);
            if (isset($full) && $full instanceof \GdImage) {
                imagedestroy($full);
            }
            if (isset($thumb) && $thumb instanceof \GdImage) {
                imagedestroy($thumb);
            }
        }
    }

    /** Delete both files behind a stored image URL. */
    public function remove(string $url, string $thumbnailUrl = ''): bool
    {
        $removed = false;
        foreach ([$url, $thumbnailUrl] as $candidate) {
            if ($candidate === '' || !str_starts_with($candidate, '/assets/uploads/products/')) {
                continue;
            }
            // Resolve and confirm the path really is inside the upload root, so
            // a crafted stored value cannot reach anything else.
            $path = realpath($this->publicPath . $candidate);
            $root = realpath($this->publicPath . '/assets/uploads/products');
            if ($path === false || $root === false || !str_starts_with($path, $root . DIRECTORY_SEPARATOR)) {
                continue;
            }
            if (is_file($path) && unlink($path)) {
                $removed = true;
            }
        }

        return $removed;
    }

    private static function decode(string $path, int $type): ?\GdImage
    {
        $image = match ($type) {
            IMAGETYPE_JPEG => @imagecreatefromjpeg($path),
            IMAGETYPE_PNG => @imagecreatefrompng($path),
            IMAGETYPE_WEBP => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($path) : false,
            IMAGETYPE_GIF => @imagecreatefromgif($path),
            IMAGETYPE_AVIF => function_exists('imagecreatefromavif') ? @imagecreatefromavif($path) : false,
            default => false,
        };

        return $image instanceof \GdImage ? $image : null;
    }

    /** Scale to fit a bounding box, preserving aspect ratio and transparency. */
    private static function fit(\GdImage $source, int $maxEdge): \GdImage
    {
        $width = imagesx($source);
        $height = imagesy($source);
        $scale = min(1.0, $maxEdge / max($width, $height));

        $targetW = max(1, (int) round($width * $scale));
        $targetH = max(1, (int) round($height * $scale));

        $target = imagecreatetruecolor($targetW, $targetH);
        imagealphablending($target, false);
        imagesavealpha($target, true);
        $transparent = imagecolorallocatealpha($target, 0, 0, 0, 127);
        imagefilledrectangle($target, 0, 0, $targetW, $targetH, $transparent);
        imagealphablending($target, true);

        imagecopyresampled($target, $source, 0, 0, 0, 0, $targetW, $targetH, $width, $height);
        imagesavealpha($target, true);

        return $target;
    }

    private static function encode(\GdImage $image, string $path, string $extension): bool
    {
        $temporary = $path . '.' . bin2hex(random_bytes(4)) . '.tmp';

        $ok = $extension === 'webp'
            ? @imagewebp($image, $temporary, 82)
            : @imagejpeg($image, $temporary, 86);

        if (!$ok || !is_file($temporary)) {
            @unlink($temporary);

            return false;
        }

        @chmod($temporary, 0o644);

        if (!rename($temporary, $path)) {
            @unlink($temporary);

            return false;
        }

        return true;
    }

    /** A directory name derived from the product slug, never from user input. */
    private static function safeSlug(string $slug): string
    {
        $clean = preg_replace('/[^a-z0-9\-]+/', '-', mb_strtolower($slug, 'UTF-8')) ?? '';
        $clean = trim($clean, '-');

        return $clean === '' ? 'misc' : mb_substr($clean, 0, 80, 'UTF-8');
    }

    /** The original filename, kept only for display in the media list. */
    private static function displayName(string $name): string
    {
        $base = basename(str_replace('\\', '/', $name));
        $base = preg_replace('/[^\p{L}\p{N}\.\-_ ]+/u', '', $base) ?? '';

        return mb_substr(trim($base), 0, 120, 'UTF-8');
    }

    private static function uploadErrorReason(int $error): string
    {
        return match ($error) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'tooLarge',
            UPLOAD_ERR_PARTIAL => 'partial',
            UPLOAD_ERR_NO_FILE => 'noFile',
            UPLOAD_ERR_NO_TMP_DIR, UPLOAD_ERR_CANT_WRITE => 'notWritable',
            UPLOAD_ERR_EXTENSION => 'blocked',
            default => 'failed',
        };
    }

    /** The effective upload ceiling, which PHP configuration can lower. */
    public static function effectiveLimitBytes(): int
    {
        $toBytes = static function (string $value): int {
            $value = trim($value);
            if ($value === '') {
                return 0;
            }
            $unit = strtolower($value[strlen($value) - 1]);
            $number = (int) $value;

            return match ($unit) {
                'g' => $number * 1024 * 1024 * 1024,
                'm' => $number * 1024 * 1024,
                'k' => $number * 1024,
                default => $number,
            };
        };

        $limits = array_filter([
            self::MAX_BYTES,
            $toBytes((string) ini_get('upload_max_filesize')),
            $toBytes((string) ini_get('post_max_size')),
        ]);

        return $limits === [] ? self::MAX_BYTES : (int) min($limits);
    }
}

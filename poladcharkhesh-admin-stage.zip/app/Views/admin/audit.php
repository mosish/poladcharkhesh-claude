<?php

declare(strict_types=1);

/**
 * @var App\Core\View $this
 * @var App\Core\Locale $locale
 * @var list<array<string,mixed>> $entries
 */
?>
<div class="adm-page">
  <header class="adm-head">
    <h1 class="adm-head__title"><?= $this->e($locale->t('admin.audit.title')) ?></h1>
    <p class="adm-head__meta"><?= $this->e((string) count($entries)) ?></p>
  </header>

  <section class="adm-card">
    <?php if ($entries === []): ?>
      <p class="adm-empty"><?= $this->e($locale->t('admin.audit.empty')) ?></p>
    <?php else: ?>
      <div class="scroll-x">
        <table class="adm-table">
          <thead>
            <tr>
              <th scope="col"><?= $this->e($locale->t('admin.audit.when')) ?></th>
              <th scope="col"><?= $this->e($locale->t('admin.audit.what')) ?></th>
              <th scope="col"><?= $this->e($locale->t('admin.audit.who')) ?></th>
              <th scope="col"><?= $this->e($locale->t('admin.audit.detail')) ?></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($entries as $entry): ?>
              <tr>
                <td class="num"><?= $this->e(str_replace('T', ' ', substr((string) ($entry['at'] ?? ''), 0, 16))) ?></td>
                <td><span class="adm-tag"><?= $this->e((string) ($entry['action'] ?? '')) ?></span></td>
                <td><?= $this->e((string) ($entry['by'] ?? '')) ?></td>
                <td><?= $this->e((string) ($entry['summary'] ?? '')) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </section>
</div>

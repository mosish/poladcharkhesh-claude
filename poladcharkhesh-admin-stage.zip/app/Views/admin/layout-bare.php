<?php

declare(strict_types=1);

/**
 * The signed-out shell, for sign-in and first-run setup.
 *
 * No navigation, because there is nothing to navigate to yet.
 *
 * @var App\Core\View $this
 * @var App\Core\App $app
 * @var App\Core\Locale $locale
 * @var App\Support\Assets $assets
 * @var string $content
 * @var string $title
 */
?>
<!DOCTYPE html>
<html lang="<?= $this->e($locale->htmlLang()) ?>" dir="<?= $this->e($locale->dir()) ?>" class="no-js admin">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?= $this->e($title) ?> — <?= $this->e($locale->t('admin.suite')) ?></title>
<meta name="robots" content="noindex, nofollow">
<meta name="theme-color" content="#0b0f24">
<link rel="stylesheet" href="<?= $this->e($assets->url('/assets/css/site.css')) ?>">
<link rel="icon" href="/assets/favicon.svg" type="image/svg+xml">
<script>document.documentElement.classList.remove('no-js');</script>
</head>
<body class="adm adm--bare">
<main class="adm-gate">
  <div class="adm-gate__panel registered">
    <a class="adm-gate__brand" href="/">
      <?= $this->partial('partials/logo', ['class' => 'adm-gate__mark', 'onDark' => true]) ?>
      <span><?= $this->e($app->company()->name($locale->language)) ?></span>
    </a>
    <?= $content ?>
  </div>
  <p class="adm-gate__foot">
    <a href="/"><?= $this->e($locale->t('admin.nav.viewSite')) ?></a>
    <span aria-hidden="true">·</span>
    <a href="<?= $this->e($app->languageToggleUrl()) ?>"><?= $this->e($locale->t('action.switchLanguage')) ?></a>
  </p>
</main>
</body>
</html>

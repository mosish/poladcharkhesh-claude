<?php

declare(strict_types=1);

/**
 * The signed-in admin shell.
 *
 * Dark by default, which separates it from the public site at a glance and
 * suits long editing sessions. It follows the same language resolution as the
 * public site, so the people who run this business read it in Persian unless
 * they switch.
 *
 * @var App\Core\View $this
 * @var App\Core\App $app
 * @var App\Core\Locale $locale
 * @var App\Support\Assets $assets
 * @var App\Http\Admin\Guard $guard
 * @var array<string,mixed>|null $admin
 * @var string $csrf
 * @var string $content
 * @var string $title
 */

use App\Support\Icons;

$nav = [
    ['href' => '/admin', 'key' => 'overview', 'icon' => 'layers'],
    ['href' => '/admin/products', 'key' => 'products', 'icon' => 'bearing'],
    ['href' => '/admin/media', 'key' => 'media', 'icon' => 'file-text'],
    ['href' => '/admin/audit', 'key' => 'audit', 'icon' => 'shield-check'],
];
$current = $app->request->path;
?>
<!DOCTYPE html>
<html lang="<?= $this->e($locale->htmlLang()) ?>" dir="<?= $this->e($locale->dir()) ?>" class="no-js admin">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?= $this->e($title) ?> — <?= $this->e($locale->t('admin.suite')) ?></title>
<meta name="robots" content="noindex, nofollow">
<meta name="theme-color" content="#0b0f24">
<link rel="stylesheet" href="<?= $this->e($assets->url('/assets/css/site.css')) ?>">
<link rel="icon" href="/assets/favicon.svg" type="image/svg+xml">
<script>document.documentElement.classList.remove('no-js');</script>
</head>
<body class="adm">

<a class="skip-link" href="#adm-main"><?= $this->e($locale->t('meta.skipToContent')) ?></a>

<header class="adm__bar">
  <button class="adm__menu" type="button" data-adm-menu
          aria-expanded="false" aria-controls="adm-nav"
          aria-label="<?= $this->e($locale->t('admin.nav.menu')) ?>">
    <span class="nav-toggle__bars" aria-hidden="true"><span></span><span></span><span></span></span>
  </button>

  <a class="adm__brand" href="/admin">
    <?= $this->partial('partials/logo', ['class' => 'adm__mark', 'onDark' => true]) ?>
    <span>
      <strong><?= $this->e($app->company()->name($locale->language)) ?></strong>
      <small><?= $this->e($locale->t('admin.suite')) ?></small>
    </span>
  </a>

  <div class="adm__bar-actions">
    <a class="adm__link" href="/" target="_blank" rel="noopener">
      <?= Icons::render('external', '', 15) ?>
      <span class="adm__link-text"><?= $this->e($locale->t('admin.nav.viewSite')) ?></span>
    </a>
    <a class="adm__link" href="<?= $this->e($app->languageToggleUrl()) ?>">
      <?= Icons::render('globe', '', 15) ?>
      <span class="adm__link-text"><?= $this->e($locale->t('action.switchLanguage')) ?></span>
    </a>
    <?php if ($admin !== null): ?>
      <form method="post" action="/admin/logout" class="adm__signout">
        <input type="hidden" name="_token" value="<?= $this->e($csrf) ?>">
        <button class="adm__link" type="submit">
          <span class="adm__link-text"><?= $this->e($locale->t('admin.nav.signOut')) ?></span>
        </button>
      </form>
    <?php endif; ?>
  </div>
</header>

<div class="adm__shell">
  <nav class="adm__nav" id="adm-nav" aria-label="<?= $this->e($locale->t('admin.nav.menu')) ?>">
    <?php foreach ($nav as $item): ?>
      <?php
      $active = $item['href'] === '/admin'
          ? $current === '/admin'
          : str_starts_with($current, $item['href']);
      ?>
      <a class="adm__nav-link" href="<?= $this->e($item['href']) ?>"
         <?= $active ? 'aria-current="page"' : '' ?>>
        <?= Icons::render($item['icon'], '', 17) ?>
        <span><?= $this->e($locale->t('admin.nav.' . $item['key'])) ?></span>
      </a>
    <?php endforeach; ?>

    <?php if ($admin !== null): ?>
      <div class="adm__who">
        <span class="adm__who-name"><?= $this->e((string) ($admin['name'] ?? '')) ?></span>
        <span class="adm__who-role"><?= $this->e((string) ($admin['username'] ?? '')) ?></span>
      </div>
    <?php endif; ?>
  </nav>

  <main class="adm__main" id="adm-main">
    <?= $content ?>
  </main>
</div>

<script type="module" src="<?= $this->e($assets->url('/assets/js/admin.js')) ?>"></script>
</body>
</html>

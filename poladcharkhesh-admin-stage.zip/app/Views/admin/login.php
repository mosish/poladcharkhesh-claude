<?php

declare(strict_types=1);

/**
 * @var App\Core\View $this
 * @var App\Core\Locale $locale
 * @var string $error
 * @var string $next
 * @var string $username
 */
?>
<h1 class="adm-gate__title"><?= $this->e($locale->t('admin.login.title')) ?></h1>
<p class="adm-gate__lead"><?= $this->e($locale->t('admin.login.lead')) ?></p>

<?php if ($error !== ''): ?>
  <p class="adm-alert adm-alert--error" role="alert"><?= $this->e($error) ?></p>
<?php endif; ?>

<form method="post" action="/admin/login" class="adm-form" novalidate>
  <input type="hidden" name="next" value="<?= $this->e($next) ?>">

  <div class="field">
    <label class="field__label" for="username"><?= $this->e($locale->t('admin.login.username')) ?></label>
    <input class="input" id="username" name="username" type="text"
           value="<?= $this->e($username) ?>"
           autocomplete="username" autocapitalize="none" spellcheck="false" required autofocus>
  </div>

  <div class="field">
    <label class="field__label" for="password"><?= $this->e($locale->t('admin.login.password')) ?></label>
    <input class="input" id="password" name="password" type="password"
           autocomplete="current-password" required>
  </div>

  <button class="btn btn--primary btn--lg btn--block" type="submit">
    <?= $this->e($locale->t('admin.login.submit')) ?>
  </button>
</form>

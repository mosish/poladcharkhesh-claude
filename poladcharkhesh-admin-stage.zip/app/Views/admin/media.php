<?php

declare(strict_types=1);

/**
 * @var App\Core\View $this
 * @var App\Core\Locale $locale
 * @var array<string,array<string,mixed>> $uploads
 * @var list<array<string,mixed>> $broken
 */
?>
<div class="adm-page">
  <header class="adm-head">
    <h1 class="adm-head__title"><?= $this->e($locale->t('admin.media.title')) ?></h1>
  </header>

  <section class="adm-card">
    <h2 class="adm-card__title">
      <?= $this->e($locale->t('admin.media.uploads')) ?>
      <span class="adm-card__count"><?= $this->e((string) count($uploads)) ?></span>
    </h2>

    <?php if ($uploads === []): ?>
      <p class="adm-empty"><?= $this->e($locale->t('admin.media.empty')) ?></p>
    <?php else: ?>
      <div class="adm-gallery">
        <?php foreach ($uploads as $url => $meta): ?>
          <figure class="adm-shot">
            <div class="adm-shot__frame">
              <img src="<?= $this->e((string) ($meta['thumbnail'] ?? $url)) ?>" alt="" loading="lazy">
            </div>
            <figcaption class="adm-shot__meta">
              <?php if (($meta['productSlug'] ?? '') !== ''): ?>
                <a class="adm-shot__link code" href="/admin/products/<?= $this->u((string) $meta['productSlug']) ?>">
                  <?= $this->e((string) $meta['productSlug']) ?>
                </a>
              <?php endif; ?>
              <span class="adm-shot__dims num">
                <?= $this->e((string) ($meta['width'] ?? '—')) ?>×<?= $this->e((string) ($meta['height'] ?? '—')) ?>
              </span>
            </figcaption>
          </figure>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>

  <?php if ($broken !== []): ?>
    <section class="adm-card">
      <h2 class="adm-card__title">
        <?= $this->e($locale->t('admin.media.broken')) ?>
        <span class="adm-card__count"><?= $this->e((string) count($broken)) ?></span>
      </h2>
      <p class="adm-card__lead"><?= $this->e($locale->t('admin.media.brokenLead')) ?></p>

      <div class="scroll-x">
        <table class="adm-table">
          <thead>
            <tr>
              <th scope="col">File</th>
              <th scope="col"><?= $this->e($locale->t('admin.media.reason')) ?></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($broken as $entry): ?>
              <tr>
                <td class="code"><?= $this->e(basename((string) ($entry['path'] ?? ''))) ?></td>
                <td><?= $this->e((string) ($entry['reason'] ?? '')) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>
  <?php endif; ?>
</div>

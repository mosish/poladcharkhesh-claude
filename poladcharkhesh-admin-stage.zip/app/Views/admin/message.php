<?php

declare(strict_types=1);

/**
 * @var App\Core\View $this
 * @var string $heading
 * @var string $message
 */
?>
<div class="adm-page">
  <section class="adm-card">
    <h1 class="adm-card__title"><?= $this->e($heading) ?></h1>
    <p class="adm-card__lead"><?= $this->e($message) ?></p>
    <p><a class="btn btn--secondary btn--sm" href="/admin/products">&larr;</a></p>
  </section>
</div>

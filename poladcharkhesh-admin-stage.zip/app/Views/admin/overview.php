<?php

declare(strict_types=1);

/**
 * @var App\Core\View $this
 * @var App\Core\Locale $locale
 * @var array<string,int> $counts
 * @var list<array<string,mixed>> $recent
 */

use App\Support\Icons;

$tiles = [
    ['key' => 'products', 'value' => $counts['products']],
    ['key' => 'withImage', 'value' => $counts['withImage']],
    ['key' => 'withoutImage', 'value' => $counts['withoutImage'], 'alert' => $counts['withoutImage'] > 0],
    ['key' => 'uploads', 'value' => $counts['uploads']],
];
?>
<div class="adm-page">
  <header class="adm-head">
    <h1 class="adm-head__title"><?= $this->e($locale->t('admin.overview.title')) ?></h1>
  </header>

  <div class="adm-tiles">
    <?php foreach ($tiles as $tile): ?>
      <div class="adm-tile <?= ($tile['alert'] ?? false) ? 'adm-tile--alert' : '' ?>">
        <span class="adm-tile__value"><?= $this->e((string) $tile['value']) ?></span>
        <span class="adm-tile__label"><?= $this->e($locale->t('admin.overview.' . $tile['key'])) ?></span>
      </div>
    <?php endforeach; ?>
  </div>

  <section class="adm-card">
    <h2 class="adm-card__title"><?= $this->e($locale->t('admin.overview.actionTitle')) ?></h2>

    <?php if ($counts['withoutImage'] > 0): ?>
      <div class="adm-todo">
        <span class="adm-todo__count"><?= $this->e((string) $counts['withoutImage']) ?></span>
        <p class="adm-todo__text"><?= $this->e($locale->t('admin.overview.noImagesLead')) ?></p>
        <a class="btn btn--primary btn--sm" href="/admin/products?missing=1">
          <?= $this->e($locale->t('admin.overview.noImagesAction')) ?>
          <?= Icons::render('arrow', 'btn__icon btn__icon--arrow', 15) ?>
        </a>
      </div>
    <?php else: ?>
      <p class="adm-empty"><?= $this->e($locale->t('admin.overview.allGood')) ?></p>
    <?php endif; ?>

    <?php if ($counts['brokenImports'] > 0): ?>
      <div class="adm-todo adm-todo--muted">
        <span class="adm-todo__count"><?= $this->e((string) $counts['brokenImports']) ?></span>
        <p class="adm-todo__text"><?= $this->e($locale->t('admin.overview.brokenLead')) ?></p>
        <a class="btn btn--secondary btn--sm" href="/admin/media">
          <?= $this->e($locale->t('admin.nav.media')) ?>
        </a>
      </div>
    <?php endif; ?>
  </section>

  <section class="adm-card">
    <h2 class="adm-card__title"><?= $this->e($locale->t('admin.overview.recent')) ?></h2>
    <?php if ($recent === []): ?>
      <p class="adm-empty"><?= $this->e($locale->t('admin.audit.empty')) ?></p>
    <?php else: ?>
      <ul class="adm-feed">
        <?php foreach ($recent as $entry): ?>
          <li class="adm-feed__item">
            <span class="adm-feed__action"><?= $this->e((string) ($entry['action'] ?? '')) ?></span>
            <span class="adm-feed__summary"><?= $this->e((string) ($entry['summary'] ?? '')) ?></span>
            <time class="adm-feed__time" datetime="<?= $this->e((string) ($entry['at'] ?? '')) ?>">
              <?= $this->e(substr((string) ($entry['at'] ?? ''), 0, 16)) ?>
            </time>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>
</div>

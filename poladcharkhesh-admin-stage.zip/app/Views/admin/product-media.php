<?php

declare(strict_types=1);

/**
 * The image manager for one product.
 *
 * Everything here is a plain form. The client script upgrades the file input
 * to a drop zone and the buttons to background requests, but with scripting
 * off every control still works — which matters for an admin panel that has to
 * keep working on a bad connection.
 *
 * @var App\Core\View $this
 * @var App\Core\App $app
 * @var App\Core\Locale $locale
 * @var App\Domain\Product $product
 * @var list<array<string,mixed>> $images
 * @var int $limitBytes
 * @var string $csrf
 * @var string $notice
 * @var string $problem
 */

use App\Support\Icons;
use App\Support\Schematics;

$megabytes = round($limitBytes / 1048576, 1);
?>
<div class="adm-page adm-page--media"
     data-media-editor
     data-slug="<?= $this->e($product->slug) ?>"
     data-csrf="<?= $this->e($csrf) ?>">

  <header class="adm-head">
    <div>
      <a class="adm-back" href="/admin/products">
        <?= Icons::render('arrow', 'adm-back__icon', 15) ?>
        <?= $this->e($locale->t('admin.products.title')) ?>
      </a>
      <h1 class="adm-head__title">
        <span class="code"><?= $this->e($product->designation()) ?></span>
      </h1>
      <p class="adm-head__meta"><?= $this->e($product->name($locale)) ?></p>
    </div>
    <a class="btn btn--secondary btn--sm" href="<?= $this->e($product->url()) ?>" target="_blank" rel="noopener">
      <?= Icons::render('external', 'btn__icon', 15) ?>
      <?= $this->e($locale->t('admin.image.viewOnSite')) ?>
    </a>
  </header>

  <?php if ($notice !== '' && $locale->t('admin.done.' . $notice) !== 'admin.done.' . $notice): ?>
    <p class="adm-alert adm-alert--ok" role="status"><?= $this->e($locale->t('admin.done.' . $notice)) ?></p>
  <?php endif; ?>
  <?php if ($problem !== ''): ?>
    <p class="adm-alert adm-alert--error" role="alert">
      <?= $this->e($locale->t('admin.problem.' . $problem, $locale->t('admin.problem.failed'))) ?>
    </p>
  <?php endif; ?>

  <section class="adm-card">
    <h2 class="adm-card__title"><?= $this->e($locale->t('admin.image.title')) ?></h2>
    <p class="adm-card__lead"><?= $this->e($locale->t('admin.image.lead')) ?></p>

    <form class="adm-drop"
          method="post"
          action="/admin/products/<?= $this->u($product->slug) ?>/images"
          enctype="multipart/form-data"
          data-upload-form>
      <input type="hidden" name="_token" value="<?= $this->e($csrf) ?>">

      <div class="adm-drop__inner" data-drop-zone>
        <?= Icons::render('file-text', 'adm-drop__icon', 26) ?>
        <p class="adm-drop__hint" data-drop-hint
           data-uploading="<?= $this->e($locale->t('admin.image.uploading')) ?>"><?= $this->e($locale->t('admin.image.dropHere')) ?></p>
        <p class="adm-drop__or"><?= $this->e($locale->t('admin.image.or')) ?></p>

        <label class="btn btn--primary btn--sm adm-drop__choose">
          <span><?= $this->e($locale->t('admin.image.choose')) ?></span>
          <input type="file" name="images[]" accept="image/jpeg,image/png,image/webp,image/avif"
                 multiple data-file-input class="visually-hidden">
        </label>

        <p class="adm-drop__limits">
          <?= $this->e($locale->t('admin.image.accepted')) ?>
          <span class="num"><?= $this->e((string) $megabytes) ?> MB</span>
        </p>
      </div>

      <noscript>
        <button class="btn btn--primary btn--sm" type="submit"><?= $this->e($locale->t('admin.image.choose')) ?></button>
      </noscript>

      <p class="adm-drop__status" data-upload-status hidden></p>
    </form>

    <?php if ($limitBytes < 5 * 1048576): ?>
      <?php // The ceiling is PHP's, not the application's — say how to raise it. ?>
      <p class="adm-alert adm-alert--warn" style="margin-block-start:var(--s-4)">
        <?= $this->e(sprintf($locale->t('admin.image.lowLimit'), $megabytes . ' MB')) ?>
      </p>
    <?php endif; ?>
  </section>

  <section class="adm-card">
    <div class="adm-gallery" data-gallery>
      <?php if ($images === []): ?>
        <div class="adm-fallback">
          <span class="adm-fallback__art"><?= Schematics::render($product->family ?? '', '', 72) ?></span>
          <div>
            <p class="adm-fallback__title"><?= $this->e($locale->t('admin.image.empty')) ?></p>
            <p class="adm-fallback__text"><?= $this->e($locale->t('admin.image.emptyLead')) ?></p>
          </div>
        </div>
      <?php else: ?>
        <?php foreach ($images as $image): ?>
          <figure class="adm-shot <?= $image['primary'] ? 'adm-shot--primary' : '' ?> <?= $image['usable'] ? '' : 'adm-shot--broken' ?>">
            <div class="adm-shot__frame">
              <?php if ($image['usable']): ?>
                <img src="<?= $this->e((string) $image['thumbnail']) ?>" alt="" loading="lazy">
              <?php else: ?>
                <?= Icons::render('alert', 'adm-shot__warning', 26) ?>
              <?php endif; ?>
              <?php if ($image['primary']): ?>
                <span class="adm-shot__badge"><?= $this->e($locale->t('admin.image.primary')) ?></span>
              <?php endif; ?>
            </div>

            <figcaption class="adm-shot__meta">
              <?php if ($image['usable']): ?>
                <span class="adm-shot__dims num">
                  <?= $this->e((string) ($image['width'] ?? '—')) ?>×<?= $this->e((string) ($image['height'] ?? '—')) ?>
                </span>
                <?php if (!$image['managed']): ?>
                  <span class="adm-shot__tag"><?= $this->e($locale->t('admin.image.imported')) ?></span>
                <?php endif; ?>
              <?php else: ?>
                <span class="adm-shot__warn"><?= $this->e($locale->t('admin.image.unusable')) ?></span>
              <?php endif; ?>
            </figcaption>

            <?php if (!$image['usable']): ?>
              <p class="adm-shot__note"><?= $this->e($locale->t('admin.image.unusableNote')) ?></p>
            <?php endif; ?>

            <div class="adm-shot__actions">
              <?php if (!$image['primary'] && $image['usable']): ?>
                <form method="post" action="/admin/products/<?= $this->u($product->slug) ?>/images/primary">
                  <input type="hidden" name="_token" value="<?= $this->e($csrf) ?>">
                  <input type="hidden" name="url" value="<?= $this->e((string) $image['url']) ?>">
                  <button class="adm-shot__action" type="submit"
                          data-set-primary="<?= $this->e((string) $image['url']) ?>">
                    <?= $this->e($locale->t('admin.image.setPrimary')) ?>
                  </button>
                </form>
              <?php endif; ?>

              <form method="post" action="/admin/products/<?= $this->u($product->slug) ?>/images/delete"
                    data-confirm="<?= $this->e($locale->t('admin.image.removeConfirm')) ?>">
                <input type="hidden" name="_token" value="<?= $this->e($csrf) ?>">
                <input type="hidden" name="url" value="<?= $this->e((string) $image['url']) ?>">
                <button class="adm-shot__action adm-shot__action--danger" type="submit"
                        data-remove="<?= $this->e((string) $image['url']) ?>">
                  <?= $this->e($locale->t('admin.image.remove')) ?>
                </button>
              </form>
            </div>
          </figure>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </section>
</div>

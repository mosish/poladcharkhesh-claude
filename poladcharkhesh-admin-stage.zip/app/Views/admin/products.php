<?php

declare(strict_types=1);

/**
 * @var App\Core\View $this
 * @var App\Core\App $app
 * @var App\Core\Locale $locale
 * @var App\Storage\MediaRepository $media
 * @var list<App\Domain\Product> $products
 * @var list<array{family:string,count:int}> $families
 * @var int $total
 * @var int $page
 * @var int $pages
 * @var string $query
 * @var string $family
 * @var bool $missing
 * @var int $withoutImages
 */

use App\Domain\Families;
use App\Support\Icons;
use App\Support\Schematics;

$pageUrl = static function (int $target) use ($query, $family, $missing): string {
    $params = array_filter([
        'q' => $query,
        'family' => $family,
        'missing' => $missing ? '1' : '',
        'page' => $target > 1 ? (string) $target : '',
    ], static fn (string $v): bool => $v !== '');

    return '/admin/products' . ($params === [] ? '' : '?' . http_build_query($params));
};
?>
<div class="adm-page">
  <header class="adm-head">
    <h1 class="adm-head__title"><?= $this->e($locale->t('admin.products.title')) ?></h1>
    <p class="adm-head__meta">
      <?= $this->e($locale->t('admin.products.showing')) ?>
      <strong><?= $this->e((string) count($products)) ?></strong>
      <?= $this->e($locale->t('admin.products.of')) ?>
      <strong><?= $this->e((string) $total) ?></strong>
    </p>
  </header>

  <form class="adm-filters" method="get" action="/admin/products">
    <div class="adm-filters__search">
      <?= Icons::render('search', '', 16) ?>
      <label class="visually-hidden" for="q"><?= $this->e($locale->t('admin.products.search')) ?></label>
      <input class="input" id="q" name="q" type="search" value="<?= $this->e($query) ?>"
             placeholder="<?= $this->e($locale->t('admin.products.search')) ?>">
    </div>

    <label class="visually-hidden" for="family"><?= $this->e($locale->t('spec.family')) ?></label>
    <select class="input adm-filters__select" id="family" name="family">
      <option value=""><?= $this->e($locale->t('admin.products.allFamilies')) ?></option>
      <?php foreach ($families as $entry): ?>
        <option value="<?= $this->e($entry['family']) ?>" <?= $family === $entry['family'] ? 'selected' : '' ?>>
          <?= $this->e(Families::label($entry['family'], $locale->language)) ?> (<?= $this->e((string) $entry['count']) ?>)
        </option>
      <?php endforeach; ?>
    </select>

    <label class="adm-check">
      <input type="checkbox" name="missing" value="1" <?= $missing ? 'checked' : '' ?>>
      <span><?= $this->e($locale->t('admin.products.missingOnly')) ?> (<?= $this->e((string) $withoutImages) ?>)</span>
    </label>

    <button class="btn btn--primary btn--sm" type="submit"><?= $this->e($locale->t('admin.products.searchAction')) ?></button>
    <?php if ($query !== '' || $family !== '' || $missing): ?>
      <a class="btn btn--ghost btn--sm" href="/admin/products"><?= $this->e($locale->t('admin.products.showAll')) ?></a>
    <?php endif; ?>
  </form>

  <?php if ($products === []): ?>
    <p class="adm-empty adm-empty--block"><?= $this->e($locale->t('admin.products.empty')) ?></p>
  <?php else: ?>
    <ul class="adm-rows">
      <?php foreach ($products as $product): ?>
        <?php
        $image = $media->firstUsable($product->gallery());
        $count = count($product->gallery());
        ?>
        <li class="adm-row">
          <span class="adm-row__thumb <?= $image === null ? 'adm-row__thumb--empty' : '' ?>">
            <?php if ($image !== null): ?>
              <img src="<?= $this->e($media->thumbnail($image)) ?>" alt="" loading="lazy" width="72" height="72">
            <?php else: ?>
              <?= Schematics::render($product->family ?? '', '', 34) ?>
            <?php endif; ?>
          </span>

          <span class="adm-row__main">
            <span class="adm-row__code code"><?= $this->e($product->designation()) ?></span>
            <span class="adm-row__name"><?= $this->e($product->name($locale)) ?></span>
          </span>

          <span class="adm-row__family"><?= $this->e($product->familyLabel($locale, true)) ?></span>

          <span class="adm-row__state">
            <?php if ($image === null): ?>
              <span class="badge badge--warnish"><?= $this->e($locale->t('admin.products.noImage')) ?></span>
            <?php else: ?>
              <span class="badge badge--stock"><?= $this->e((string) $count) ?> <?= $this->e($locale->t('admin.products.imageCount')) ?></span>
            <?php endif; ?>
          </span>

          <a class="btn btn--secondary btn--sm" href="/admin/products/<?= $this->u($product->slug) ?>">
            <?= $this->e($locale->t('admin.products.manage')) ?>
          </a>
        </li>
      <?php endforeach; ?>
    </ul>

    <?php if ($pages > 1): ?>
      <nav class="adm-pager" aria-label="<?= $this->e($locale->t('admin.products.title')) ?>">
        <?php if ($page > 1): ?>
          <a class="btn btn--secondary btn--sm" href="<?= $this->e($pageUrl($page - 1)) ?>"><?= $this->e($locale->t('admin.products.previous')) ?></a>
        <?php endif; ?>
        <span class="adm-pager__pos"><?= $this->e((string) $page) ?> / <?= $this->e((string) $pages) ?></span>
        <?php if ($page < $pages): ?>
          <a class="btn btn--secondary btn--sm" href="<?= $this->e($pageUrl($page + 1)) ?>"><?= $this->e($locale->t('admin.products.next')) ?></a>
        <?php endif; ?>
      </nav>
    <?php endif; ?>
  <?php endif; ?>
</div>

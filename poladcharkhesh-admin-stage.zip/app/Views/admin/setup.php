<?php

declare(strict_types=1);

/**
 * First-run provisioning.
 *
 * Reachable only while no administrator exists. There are no default
 * credentials anywhere in this project; this form is how the first account
 * comes into being.
 *
 * @var App\Core\View $this
 * @var App\Core\Locale $locale
 * @var array<string,string> $errors
 * @var array<string,string> $values
 */

$value = static fn (string $key): string => $values[$key] ?? '';
$error = static fn (string $key): string => $errors[$key] ?? '';
?>
<h1 class="adm-gate__title"><?= $this->e($locale->t('admin.setup.title')) ?></h1>
<p class="adm-gate__lead"><?= $this->e($locale->t('admin.setup.lead')) ?></p>

<form method="post" action="/admin/setup" class="adm-form" novalidate>
  <div class="field">
    <label class="field__label" for="name"><?= $this->e($locale->t('admin.setup.name')) ?></label>
    <input class="input" id="name" name="name" type="text" value="<?= $this->e($value('name')) ?>"
           autocomplete="name" required autofocus>
    <?php if ($error('name') !== ''): ?>
      <p class="field__error"><?= $this->e($error('name')) ?></p>
    <?php endif; ?>
  </div>

  <div class="field">
    <label class="field__label" for="username"><?= $this->e($locale->t('admin.setup.username')) ?></label>
    <input class="input" id="username" name="username" type="text" value="<?= $this->e($value('username')) ?>"
           autocomplete="username" autocapitalize="none" spellcheck="false" required>
    <?php if ($error('username') !== ''): ?>
      <p class="field__error"><?= $this->e($error('username')) ?></p>
    <?php endif; ?>
  </div>

  <div class="field">
    <label class="field__label" for="email"><?= $this->e($locale->t('admin.setup.email')) ?></label>
    <input class="input" id="email" name="email" type="email" value="<?= $this->e($value('email')) ?>"
           autocomplete="email" dir="ltr">
    <?php if ($error('email') !== ''): ?>
      <p class="field__error"><?= $this->e($error('email')) ?></p>
    <?php endif; ?>
  </div>

  <div class="field">
    <label class="field__label" for="password"><?= $this->e($locale->t('admin.setup.password')) ?></label>
    <input class="input" id="password" name="password" type="password"
           autocomplete="new-password" required minlength="12">
    <p class="field__hint"><?= $this->e($locale->t('admin.setup.passwordHint')) ?></p>
    <?php if ($error('password') !== ''): ?>
      <p class="field__error"><?= $this->e($error('password')) ?></p>
    <?php endif; ?>
  </div>

  <div class="field">
    <label class="field__label" for="password_confirm"><?= $this->e($locale->t('admin.setup.confirm')) ?></label>
    <input class="input" id="password_confirm" name="password_confirm" type="password"
           autocomplete="new-password" required>
    <?php if ($error('password_confirm') !== ''): ?>
      <p class="field__error"><?= $this->e($error('password_confirm')) ?></p>
    <?php endif; ?>
  </div>

  <button class="btn btn--primary btn--lg btn--block" type="submit">
    <?= $this->e($locale->t('admin.setup.submit')) ?>
  </button>
</form>

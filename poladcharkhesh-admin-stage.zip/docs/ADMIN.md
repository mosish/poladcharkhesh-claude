# Admin panel

`/admin`. Bilingual, following the same language resolution as the public
site — Persian by default on `.ir`, English on `.com`, switchable from the top
bar.

Today it manages **product images**. Specification editing, CMS, company
details, SEO and inquiries follow in Phase G; nothing here pretends they exist.

---

## 1. First run

There are no shipped credentials. On a fresh deployment `/admin/setup` creates
the first administrator, and that route stops working the moment an account
exists.

The password must be at least 12 characters, must not contain the username,
and must not contain a word from a short list of very common ones. Length is
what the rule is about: a long passphrase beats a short password with symbols
in it.

If you lose access, delete `data/store/admins.json` on the server and the setup
route opens again. That is the recovery path — it requires filesystem access,
which is the point.

## 2. Sessions

The cookie carries a 256-bit random token; the store keeps only its SHA-256
digest, so a copy of the data directory cannot be replayed as a live session.

- Absolute lifetime: 12 hours.
- Idle timeout: 90 minutes.
- The cookie is `HttpOnly`, `SameSite=Lax`, scoped to `/admin`, and `Secure`
  once the site is on HTTPS.
- Signing out revokes the session server-side, not just in the browser.

Sign-in attempts are throttled on two keys: address plus username (5 failures
in 15 minutes, then a 15-minute lock) and address alone (20 failures). The
tighter key stops a password being guessed; the looser one stops a single
client working through a list of usernames. While locked, even the correct
password is refused. The response never says whether a username exists, and an
unknown username still costs a full hash verification so the timing does not
give it away either.

## 3. Managing product images

**Products → Manage images**, or go straight to
`/admin/products/<slug>`.

Filter the list by family, search by designation or name, or tick
**Missing images only** to work through what still needs a photograph.

On a product page you can:

- **Upload** by dropping files onto the panel or choosing them — several at
  once, up to twelve per batch.
- **Make primary.** The first image is the one the catalogue card shows.
- **Remove.** Files this application created are deleted from disk; an
  imported path is only detached from the product, since it may be referenced
  elsewhere and is not ours to delete.

The first working upload automatically becomes primary when the current
primary is one of the corrupted imported files, so the card stops showing a
fallback as soon as there is something real to show.

Every control is an ordinary form. The drag-and-drop, progress figure and
in-place refresh are enhancements; with scripting off, everything still works.

## 4. What happens to an uploaded file

Nothing about the upload is trusted — not the extension, not the
`Content-Type` the browser claimed, not the filename.

1. The size is checked against the smaller of 10 MB and the server's own limit.
2. The type is read from the file's leading bytes. JPEG, PNG, WebP, AVIF and
   GIF are accepted; anything else is refused.
3. Very small images (under 200 px on both edges) and absurd pixel counts are
   refused.
4. The image is **decoded with GD and re-encoded**. This is the important step,
   and it does four jobs at once: it proves the file really is an image, it
   destroys anything smuggled in the metadata, it strips EXIF including GPS
   tags, and it normalises the format.
5. Two files are written — a full view capped at 1600 px and a 640 px card
   thumbnail — as WebP, named from the content hash.
6. The result is recorded in the media registry, which is what the public site
   consults before rendering an image.

Because everything is re-encoded, an accepted image is guaranteed to display.
That is the direct answer to how the imported catalogue ended up full of files
that served correctly and rendered nothing.

`public/assets/uploads/.htaccess` turns off the PHP engine, strips script
handlers and denies executable extensions in that directory — belt as well as
braces, since nothing executable should ever get written there in the first
place.

### If uploads are rejected as too large

The ceiling shown under the drop zone is PHP's, not the application's. cPanel
often ships 2 MB, which is smaller than a phone photograph. Raise it in
**MultiPHP INI Editor**:

```
upload_max_filesize = 16M
post_max_size = 20M
```

The panel shows this note itself when the limit is under 5 MB.

## 5. Audit log

Recorded: `ADMIN_PROVISIONED`, `LOGIN`, `LOGIN_FAILED`, `LOGIN_THROTTLED`,
`LOGOUT`, `CSRF_REJECTED`, `MEDIA_UPLOADED`, `MEDIA_REJECTED`,
`MEDIA_DELETED`, `PRODUCT_UPDATED`.

Passwords, tokens, cookies and secrets never reach it. Rather than trusting
every call site to remember that, the repository filters those field names out
of any payload on the way in, at any depth. The suite asserts it.

## 6. Boundaries

The image controller writes exactly two fields: `imageUrl` and `images`. There
is no code path from an image route to a load rating or a dimension — not a
filtered one, an absent one. A crafted request carrying `crKn=999` changes
nothing, and the test suite checks that specifically.

Deleting is confined to the upload directory by resolving the real path and
confirming it sits inside that root, so a tampered stored value cannot reach
anything else on disk.

## 7. Testing

```bash
php -S 127.0.0.1:8080 -t public &
bash tests/admin_flow.sh
```

51 assertions covering setup, sign-in, session handling, CSRF, upload
validation, the public-site effect, primary and delete, mass assignment,
throttling and the audit log. It snapshots the data store first and restores it
afterwards, so running it leaves nothing behind.

Screenshots of every screen in both languages:

```bash
CHROMIUM_PATH=/path/to/chromium node scripts/screenshots_admin.mjs
```

# Data model

## The store

`data/store/` holds one JSON document per collection.

| File | Shape | Contents |
|---|---|---|
| `products.json` | array | The 68-reference catalogue |
| `company.json` | object | The authoritative company record |
| `content.json` | object | Editable site copy, Persian and English side by side |
| `seo.json` | object | Site-wide SEO defaults and the canonical hosts |
| `media.json` | object | Which assets decode, and every admin upload |
| `audit.json` | array | Administrator actions, append-only |
| `inquiries.json` | array | Enquiries (not yet built) |

Three more are written at runtime and are **not** committed — they are live
state, and `admins.json` holds password hashes:

| File | Contents |
|---|---|
| `admins.json` | Administrator accounts and their password hashes |
| `sessions.json` | Live sessions, holding only a digest of each token |
| `throttle.json` | Failed sign-in counters, keyed by hash |

## Product

Field names are camelCase in JSON. Everything below `family` came across from
the reference database unchanged.

**Identity** — `id`, `code`, `slug`, `category`, `family`, `familyConfidence`,
`familySource`

**Localised** — `nameFa`, `nameEn`, `descriptionFa`, `descriptionEn`

**State** — `inStock`, `featured`, `isArchived`

**Principal dimensions** (mm) — `d` bore, `D` outside diameter, `B` width,
`rMin` corner radius

**Mass** — `weightKg`

**Load ratings** (kN) — `crKn` basic dynamic, `corKn` basic static

**Speeds** (r/min) — `speedGreaseRpm`, `speedOilRpm`, `thermalSpeedRatingRpm`

**Construction** — `cageMaterialFa` / `cageMaterialEn`, `sealingFa` /
`sealingEn`, `clearanceOptions`, `schematicType`

**Calculation factors** — `factorE`, `factorY`, `factorY0`, `factorY1`,
`factorY2`, `factorF0`. These are per-reference, not per-category: the
calculator reads them from the selected product rather than applying one
factor to every bearing.

**Commercial context** — `brands`, `applicationsFa`, `applicationsEn`,
`industryIds`

**Media** — `imageUrl`, `images`, `pdfUrl`

**Provenance** — `technicalSources`, each with `manufacturer`, `sourceType`,
`reference` and `verifiedAt`

**SEO** — `metaTitleFa`, `metaTitleEn`, `metaDescriptionFa`,
`metaDescriptionEn`

**Audit** — `createdAt`, `updatedAt`, `updatedBy`

`null` means "not specified" and is rendered as such. It is never filled in
with a plausible value.

## Family derivation

`family` is the one field the migration added. It is derived from the ISO/DIN
designation by `scripts/migrate_from_reference.py`, and stored alongside the
rule that produced it and a confidence.

The rules read the designation the way a parts desk does — digit count first,
because it disambiguates the series:

| Designation | Family | Why |
|---|---|---|
| `6xxx` | deep groove ball | 4-digit series 6 |
| `7xxx` | angular contact ball | 4-digit series 7 |
| `32xx` `33xx` `52xx` `53xx` | angular contact ball, double row | 4-digit |
| `12xx` `13xx` `22xx` `23xx` | self-aligning ball | 4-digit series 1 or 2 |
| `30xxx` `31xxx` `32xxx` `33xxx` | tapered roller | 5-digit |
| `222xx` `223xx` `230xx` `231xx` `232xx` | spherical roller | 5-digit |
| `511xx` – `514xx` | thrust ball | 5-digit |
| `292xx` `293xx` `294xx` | spherical roller thrust | 5-digit |
| `NU` `NJ` `NUP` `N` `NCF` | cylindrical roller | prefix |
| `NA` `NK` `NKI` `KR` | needle roller / track roller | prefix |
| `C…` / CARB | toroidal roller | prefix |
| `UCP` `UCF` `UCFL` `UCT` | bearing unit | prefix |
| `SNL` `SN` `SAF` | bearing housing | prefix |
| `TC…` / Simmerring | oil seal | seal designation |
| LGMT, grease wording | lubricant | product wording |
| `LM` `L` `M` `HM` sets | tapered roller | imperial cup/cone |

Note that `3308` is a double row angular contact bearing and `32210` is a
tapered roller bearing. The digit count is what separates them, which is why
the rules check length before prefix.

All 68 references resolve at high confidence.

## What was flagged, reviewed and then corrected

The migration flagged twelve references where the imported `schematicType`
disagreed with the product's own name and designation, and changed nothing —
the brief's data principle is detect → flag → source → compare → human review
→ approve → update, and only the first two steps belong to a migration.

The owner reviewed the list and approved correcting all products from their
designations. `scripts/apply_schematic_corrections.py` is the approve step:

| Reference | Was | Now |
|---|---|---|
| 7312 BECBM | deep-groove | angular-contact |
| 7210 BECBP / P6 | deep-groove | angular-contact |
| 3308 A-2Z/C3 | deep-groove | angular-contact |
| NSK 7010 CTYNDBLP4 | deep-groove | angular-contact |
| NTN 5206 S | deep-groove | angular-contact |
| 1309 EKTN9 | deep-groove | self-aligning-ball |
| NA 4910 | cylindrical | needle |
| INA NK 25/20 | cylindrical | needle |
| INA KR 35 PP | cylindrical | needle |
| SKF C 2215 K | cylindrical | carb |
| SKF LGMT 2 | deep-groove | *(cleared — a grease has no section)* |
| Mobilith SHC 220 | spherical | *(cleared)* |

A thirteenth was corrected in the same pass: `29420 E` is a spherical roller
thrust bearing stored as a plain `thrust`, which is compatible enough not to
have been flagged but still draws the wrong section. Every record now carries
the canonical section for its family.

This mattered beyond the drawing. The brief requires family-specific
calculation, and an angular contact bearing evaluated with deep-groove logic
returns a wrong equivalent load.

Each change is recorded in `data/store/audit.json` with its old value, its new
value and the rule that justified it, so every one is reviewable and
reversible. `data/migration-review.json` is kept rather than deleted, marked
resolved, so the record of what had been wrong stays with the project.

Engineering values were not touched: the field-by-field verification below was
re-run afterwards and still reports zero drift.

## Verification

The migration checks itself. Every numeric field, every text field and every
technical-source record is compared against the source database after writing:

```
verification: 0 drifts across 68 products x 25 fields
technical source records preserved: 68
```

Re-run with:

```bash
python3 scripts/migrate_from_reference.py <path-to-reference.db> data/store
```

## Media

`media.json` records which referenced assets decode. It is written by
`scripts/audit_assets.py` and read by `Storage\MediaRepository`.

At the time of migration the answer was **none of them**:

```
referenced assets : 29
usable            : 0
unusable          : 29
products with no usable image: 68
```

Every product image in the reference repository has been through a UTF-8 text
decode at some point in its history. Each byte that was not valid UTF-8 was
replaced with the replacement character U+FFFD (`EF BF BD`), which is why the
files are roughly twice their original size and why the RIFF length fields no
longer match. The compressed image data is destroyed; this is not recoverable
by re-encoding.

The files still serve with a 200 and the right MIME type, so a browser requests
them, fails to decode them, and renders nothing. That is why the check exists
as a build step rather than as a runtime guess.

Until original photography is supplied, product cards render the family's
technical section symbol from `Support\Schematics`. That was chosen over the
two alternatives deliberately: a broken image reads as neglect, and a stock
photograph would be a picture of a part the company is not selling.

Replacements are uploaded through the admin panel, which decodes and re-encodes
every file before storing it — so an accepted image is one this server has
provably read. `uploads` in the registry is the list of those, and the public
site treats an entry there exactly as it treats an audited import. See
`docs/ADMIN.md`.

## Industry links

`industryIds` on every product contains the same two values, `steel` and
`mining`. That is a seeding artefact, not curation, so the industries section
links to bearing **families** rather than to product lists. Presenting
per-industry product lists from this data would be presenting noise as
knowledge.

<?php

declare(strict_types=1);

/**
 * Front controller.
 *
 * Every request that is not a static file reaches this file through the
 * rewrite rule in .htaccess.
 */

require dirname(__DIR__) . '/app/bootstrap.php';

use App\Core\App;
use App\Core\Config;
use App\Core\Locale;
use App\Core\Request;
use App\Core\Response;
use App\Core\Router;
use App\Http\Admin\AuthController;
use App\Http\Admin\DashboardController;
use App\Http\Admin\Guard;
use App\Http\Admin\ProductController;
use App\Http\HomeController;
use App\Storage\StoreException;

$request = Request::fromGlobals();
$app = App::boot($request);

// Remember an explicit language choice so the visitor keeps it while browsing,
// including across the .ir / .com pair where each domain has its own default.
$chosen = strtolower($request->queryString('lang'));
if (in_array($chosen, Locale::SUPPORTED, true) && !headers_sent()) {
    setcookie(Locale::COOKIE, $chosen, [
        'expires' => time() + 31_536_000,
        'path' => '/',
        'secure' => $request->secure,
        'httponly' => false, // read by the language toggle in the client
        'samesite' => 'Lax',
    ]);
}

$router = new Router();

// --- public ---------------------------------------------------------------
$home = new HomeController($app);
$router->get('/', $home->index(...));

// --- administration -------------------------------------------------------
// Guard is constructed once and shared, so a request resolves its session
// exactly once no matter how many controllers touch it.
$guard = new Guard($app);
$auth = new AuthController($app, $guard);
$dashboard = new DashboardController($app, $guard);
$products = new ProductController($app, $guard);

$router->get('/admin', $dashboard->overview(...));
$router->get('/admin/media', $dashboard->media(...));
$router->get('/admin/audit', $dashboard->audit(...));

$router->get('/admin/setup', $auth->showSetup(...));
$router->post('/admin/setup', $auth->submitSetup(...));
$router->get('/admin/login', $auth->showLogin(...));
$router->post('/admin/login', $auth->submitLogin(...));
$router->post('/admin/logout', $auth->logout(...));

$router->get('/admin/products', $products->index(...));
$router->get('/admin/products/{slug}', $products->edit(...));
$router->post('/admin/products/{slug}/images', $products->upload(...));
$router->post('/admin/products/{slug}/images/primary', $products->setPrimary(...));
$router->post('/admin/products/{slug}/images/delete', $products->deleteImage(...));

$router->fallback($home->notFound(...));

try {
    $response = $router->dispatch($request);
} catch (StoreException $e) {
    error_log('[store] ' . $e->getMessage());
    $response = $home->serviceUnavailable();
} catch (\Throwable $e) {
    error_log('[error] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    if (!Config::isProduction()) {
        throw $e;
    }
    $response = $home->serverError();
}

// Admin pages are never indexed, whatever a crawler was told elsewhere.
if (str_starts_with($request->path, '/admin')) {
    $response = $response->withHeader('X-Robots-Tag', 'noindex, nofollow');
}

$response->send();

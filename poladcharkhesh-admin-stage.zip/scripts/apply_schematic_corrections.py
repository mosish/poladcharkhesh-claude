#!/usr/bin/env python3
"""
Apply the schematic-type corrections the migration flagged.

The migration deliberately does not repair data. It detects a discrepancy,
records it, and stops — the remaining steps of the brief's data workflow
(source, compare, confidence, human review, approve) belong to a person.

This script is the "approve" step, run once, on the owner's explicit
instruction to correct all products from their designations. It:

  - sets `schematicType` to the canonical section for each record's derived
    family, and clears it for the two lubricants, which have no cross-section;
  - writes an audit entry per change recording the old value, the new value,
    the rule that justified it and who approved it;
  - marks the review file resolved rather than deleting it, so the history of
    what was wrong stays with the project.

Engineering values are not touched. Only `schematicType` changes.

Usage:  python3 scripts/apply_schematic_corrections.py [--store data/store] [--dry-run]
"""

from __future__ import annotations

import argparse
import datetime
import json
import pathlib
import sys

# The canonical section drawing for each family. Mirrors App\Domain\Families.
FAMILY_SCHEMATIC: dict[str, str | None] = {
    "deep-groove-ball": "deep-groove",
    "angular-contact-ball": "angular-contact",
    "self-aligning-ball": "self-aligning-ball",
    "tapered-roller": "tapered",
    "spherical-roller": "spherical",
    "toroidal-roller": "carb",
    "cylindrical-roller": "cylindrical",
    "needle-roller": "needle",
    "thrust-ball": "thrust",
    "spherical-thrust-roller": "spherical-thrust",
    "bearing-unit": "pillow-block",
    "bearing-housing": "pillow-block",
    "oil-seal": "oil-seal",
    "lubricant": None,
}

APPROVED_BY = "owner-approval:2026-09-08"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--store", default="data/store")
    parser.add_argument("--review", default="data/migration-review.json")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    store = pathlib.Path(args.store)
    review_path = pathlib.Path(args.review)

    products = json.loads((store / "products.json").read_text(encoding="utf-8"))
    review = json.loads(review_path.read_text(encoding="utf-8"))

    flagged = {
        record["slug"]: record
        for record in review.get("records", [])
        if record.get("derivedFamily")
    }

    # The migration only flagged records where the stored section was
    # *incompatible* with the derived family. A few were merely imprecise — a
    # spherical roller thrust bearing stored as a plain thrust bearing, say,
    # which is compatible but draws the wrong section. Aligning every record to
    # its family's canonical section is what "correct all products from the
    # designations" means, so the sweep covers all 68 rather than only the
    # twelve that were incompatible enough to flag.
    for product in products:
        flagged.setdefault(
            product["slug"],
            {
                "slug": product["slug"],
                "derivedFamily": product.get("family"),
                "rule": "aligned to the canonical section for the derived family",
            },
        )

    now = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
    changes: list[dict[str, object]] = []

    for product in products:
        record = flagged.get(product["slug"])
        if record is None:
            continue

        family = product.get("family")
        if family not in FAMILY_SCHEMATIC:
            print(f"  skipped {product['code']}: family '{family}' has no canonical section")
            continue

        target = FAMILY_SCHEMATIC[family]
        current = product.get("schematicType")
        if current == target:
            continue

        changes.append({
            "code": product["code"],
            "slug": product["slug"],
            "field": "schematicType",
            "from": current,
            "to": target,
            "family": family,
            "rule": record.get("rule", ""),
        })

        if not args.dry_run:
            product["schematicType"] = target
            product["updatedAt"] = now
            product["updatedBy"] = APPROVED_BY

    if not changes:
        print("  nothing to correct")
        return 0

    width = max(len(str(c["code"])) for c in changes)
    for change in changes:
        print(f"  {str(change['code'])[:width]:{width}}  {str(change['from']):18} -> {str(change['to'])}")

    if args.dry_run:
        print(f"\n  {len(changes)} corrections (dry run, nothing written)")
        return 0

    (store / "products.json").write_text(
        json.dumps(products, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    # Audit trail. Every correction is recorded with what it was, so the change
    # is reversible and reviewable rather than invisible.
    audit_path = store / "audit.json"
    audit = json.loads(audit_path.read_text(encoding="utf-8")) if audit_path.is_file() else []
    if not isinstance(audit, list):
        audit = []
    for change in changes:
        audit.append({
            "id": f"corr-{change['slug']}-schematic",
            "action": "PRODUCT_UPDATED",
            "at": now,
            "by": APPROVED_BY,
            "target": change["slug"],
            "summary": (
                f"schematicType corrected from {change['from']} to {change['to']} "
                f"({change['family']}, derived from designation)"
            ),
            "before": {"schematicType": change["from"]},
            "after": {"schematicType": change["to"]},
            "justification": change["rule"],
        })
    audit_path.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    # Keep the review file as history rather than deleting the record of what
    # had been wrong.
    review["resolvedAt"] = now
    review["resolvedBy"] = APPROVED_BY
    review["resolution"] = (
        "schematicType corrected from each product's ISO/DIN designation on the "
        "owner's instruction. Engineering values were not modified."
    )
    for record in review.get("records", []):
        record["status"] = "resolved" if record["slug"] in flagged else "open"
    review_path.write_text(
        json.dumps(review, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    print(f"\n  {len(changes)} corrections applied, {len(changes)} audit entries written")
    return 0


if __name__ == "__main__":
    sys.exit(main())

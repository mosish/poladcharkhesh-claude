/**
 * Visual verification of the admin panel.
 *
 * Signs in through the real form, exercises the image editor with genuine
 * uploads, and captures each screen in both languages. It restores the data
 * store afterwards, so running it never leaves state behind.
 */

import { execSync } from 'node:child_process';
import { cpSync, mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { chromium } from 'playwright';

const BASE = process.env.BASE_URL ?? 'http://127.0.0.1:8080';
const ROOT = path.resolve('.');
const OUT = path.resolve('screenshots');
const STORE = path.join(ROOT, 'data/store');
const UPLOADS = path.join(ROOT, 'public/assets/uploads/products');

const USER = 'preview-owner';
// Deliberately not containing a banned word — the validator refuses those,
// which is how this script found out it works.
const PASSWORD = 'gearbox-lantern-quarry-47';

const snapshot = mkdtempSync(path.join(tmpdir(), 'polad-store-'));
// Scratch for the generated upload fixtures. Deliberately *not* the snapshot
// directory: that one is copied back over data/store on restore, so anything
// written into it would end up in the committed store.
const scratch = mkdtempSync(path.join(tmpdir(), 'polad-fixtures-'));

function restore() {
  cpSync(snapshot, STORE, { recursive: true });
  rmSync(path.join(UPLOADS, 'nu-208-ecp'), { recursive: true, force: true });
  rmSync(snapshot, { recursive: true, force: true });
  rmSync(scratch, { recursive: true, force: true });
}

/** Draw a plausible product photograph so the editor has something to show. */
function makeImage(file, seed) {
  execSync(
    `php -r '$w=1200;$h=900;$i=imagecreatetruecolor($w,$h);` +
      `imagefill($i,0,0,imagecolorallocate($i,246,247,249));` +
      `$cx=$w/2;$cy=$h/2;` +
      `imagefilledellipse($i,$cx,$cy,700,700,imagecolorallocate($i,${170 + seed * 12},${178 + seed * 8},${192 + seed * 6}));` +
      `imagefilledellipse($i,$cx,$cy,600,600,imagecolorallocate($i,232,236,242));` +
      `imagefilledellipse($i,$cx,$cy,420,420,imagecolorallocate($i,${150 + seed * 10},${160 + seed * 8},${180 + seed * 6}));` +
      `imagefilledellipse($i,$cx,$cy,300,300,imagecolorallocate($i,246,247,249));` +
      `for($k=0;$k<10;$k++){$a=$k*M_PI/5;` +
      `imagefilledellipse($i,$cx+cos($a)*258,$cy+sin($a)*258,74,74,imagecolorallocate($i,238,241,246));}` +
      `imagejpeg($i,"${file}",92);'`,
    { cwd: ROOT },
  );
}

async function run() {
  mkdirSync(OUT, { recursive: true });
  cpSync(STORE, snapshot, { recursive: true });

  // A clean, provisioned panel.
  for (const name of ['admins', 'sessions', 'throttle']) {
    writeFileSync(path.join(STORE, `${name}.json`), '[]\n');
  }

  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const problems = [];

  const shoot = async (page, name) => {
    await page.waitForLoadState('networkidle');
    await page.evaluate(() => document.fonts?.ready);
    await page.waitForTimeout(300);
    await page.screenshot({ path: path.join(OUT, `admin-${name}.png`) });
  };

  const context = await browser.newContext({
    viewport: { width: 1440, height: 980 },
    deviceScaleFactor: 2,
  });
  const page = await context.newPage();
  page.on('pageerror', (e) => problems.push(`pageerror: ${e.message}`));
  page.on('console', (m) => m.type() === 'error' && problems.push(`console: ${m.text()}`));
  page.on('response', (r) => r.status() >= 400 && problems.push(`${r.status()} ${r.url()}`));

  // --- setup, in Persian --------------------------------------------------
  await page.goto(`${BASE}/admin/setup?lang=fa`);
  await shoot(page, 'setup-fa');

  await page.fill('#name', 'مصطفی شاهی');
  await page.fill('#username', USER);
  await page.fill('#password', PASSWORD);
  await page.fill('#password_confirm', PASSWORD);
  await Promise.all([
    page.waitForURL((url) => url.pathname === '/admin'),
    page.click('button[type=submit]'),
  ]);

  await page.goto(`${BASE}/admin?lang=fa`);
  await shoot(page, 'overview-fa');

  await page.goto(`${BASE}/admin/products?lang=fa`);
  await shoot(page, 'products-fa');

  // --- the image editor, before and after ---------------------------------
  await page.goto(`${BASE}/admin/products/nu-208-ecp?lang=fa`);
  await shoot(page, 'product-empty-fa');

  const files = [];
  for (let i = 0; i < 2; i += 1) {
    const file = path.join(scratch, `preview-${i}.jpg`);
    makeImage(file, i);
    files.push(file);
  }
  await page.setInputFiles('[data-file-input]', files);
  await page.waitForTimeout(2500);
  await shoot(page, 'product-filled-fa');

  await page.goto(`${BASE}/admin/products/nu-208-ecp?lang=en`);
  await shoot(page, 'product-filled-en');

  await page.goto(`${BASE}/admin/media?lang=fa`);
  await shoot(page, 'media-fa');

  await page.goto(`${BASE}/admin/audit?lang=en`);
  await shoot(page, 'audit-en');

  // Whether an upload reaches the public catalogue is asserted in
  // tests/admin_flow.sh, against a product the home page actually features.

  await context.close();

  // --- mobile -------------------------------------------------------------
  const mobile = await browser.newContext({
    viewport: { width: 390, height: 844 },
    deviceScaleFactor: 2,
  });
  const mobilePage = await mobile.newPage();
  await mobilePage.goto(`${BASE}/admin/login?lang=fa`);
  await mobilePage.fill('#username', USER);
  await mobilePage.fill('#password', PASSWORD);
  await Promise.all([
    mobilePage.waitForURL((url) => url.pathname === '/admin'),
    mobilePage.click('button[type=submit]'),
  ]);
  await mobilePage.goto(`${BASE}/admin/products/nu-208-ecp?lang=fa`);
  await shoot(mobilePage, 'product-mobile-fa');
  await mobile.close();

  await browser.close();

  console.log(problems.length === 0
    ? '\nAdmin captured with no console errors or failed requests.'
    : `\nPROBLEMS\n  ${[...new Set(problems)].join('\n  ')}`);
}

try {
  await run();
} finally {
  restore();
  console.log('  data store restored');
}

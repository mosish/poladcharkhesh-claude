/**
 * Admin entry point.
 *
 * A separate bundle from the public site: the admin needs none of the bearing
 * renderer, and visitors need none of this. Each island is initialised in
 * isolation so one failing cannot take the panel down — an administrator with
 * a broken drop zone must still be able to use the plain file input.
 */

import { initAdminNav, initMediaEditor } from './islands/media-editor';

function safely(name: string, fn: () => void): void {
  try {
    fn();
  } catch (error) {
    console.warn(`[polad-admin] ${name} failed to initialise`, error);
  }
}

function boot(): void {
  safely('admin navigation', initAdminNav);
  safely('media editor', initMediaEditor);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot, { once: true });
} else {
  boot();
}

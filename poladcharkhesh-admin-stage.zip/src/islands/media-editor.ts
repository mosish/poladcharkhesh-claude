/**
 * The product image editor.
 *
 * Every control on the page is already a working form. This upgrades them:
 * files can be dropped, uploads report progress, and the gallery refreshes in
 * place instead of reloading the page.
 *
 * After any change the gallery markup is re-fetched from the server rather
 * than re-rendered from JSON. That keeps every label, date format and
 * right-to-left decision in one place — the PHP templates — instead of
 * duplicating them here where they would quietly drift.
 */

type Status = 'busy' | 'ok' | 'error';

interface UploadResponse {
  ok: boolean;
  added?: string[];
  rejected?: string[];
  error?: string;
}

function setStatus(el: HTMLElement | null, message: string, state: Status | null): void {
  if (!el) return;
  el.textContent = message;
  el.hidden = message === '';
  if (state === null) {
    el.removeAttribute('data-state');
  } else {
    el.dataset.state = state;
  }
}

/** Re-fetch this page and swap in its gallery, so labels stay server-rendered. */
async function refreshGallery(root: HTMLElement): Promise<void> {
  const gallery = root.querySelector<HTMLElement>('[data-gallery]');
  if (!gallery) return;

  const response = await fetch(window.location.href, {
    headers: { 'X-Requested-With': 'refresh' },
    credentials: 'same-origin',
  });
  if (!response.ok) return;

  const parsed = new DOMParser().parseFromString(await response.text(), 'text/html');
  const fresh = parsed.querySelector('[data-gallery]');
  if (fresh) {
    gallery.replaceChildren(...Array.from(fresh.childNodes));
  }
}

/**
 * Upload with XMLHttpRequest rather than fetch, because fetch still cannot
 * report upload progress — and on a slow connection with a few photographs,
 * a progress figure is the difference between waiting and wondering.
 */
function upload(action: string, data: FormData, onProgress: (percent: number) => void): Promise<UploadResponse> {
  return new Promise((resolve, reject) => {
    const request = new XMLHttpRequest();
    request.open('POST', action);
    request.setRequestHeader('X-Requested-With', 'fetch');
    request.setRequestHeader('Accept', 'application/json');
    request.withCredentials = true;

    request.upload.addEventListener('progress', (event) => {
      if (event.lengthComputable) {
        onProgress(Math.round((event.loaded / event.total) * 100));
      }
    });

    request.addEventListener('load', () => {
      try {
        resolve(JSON.parse(request.responseText) as UploadResponse);
      } catch {
        reject(new Error('badResponse'));
      }
    });
    request.addEventListener('error', () => reject(new Error('network')));
    request.addEventListener('abort', () => reject(new Error('aborted')));

    request.send(data);
  });
}

export function initMediaEditor(): void {
  const root = document.querySelector<HTMLElement>('[data-media-editor]');
  if (!root) return;

  const form = root.querySelector<HTMLFormElement>('[data-upload-form]');
  const input = root.querySelector<HTMLInputElement>('[data-file-input]');
  const zone = root.querySelector<HTMLElement>('[data-drop-zone]');
  const status = root.querySelector<HTMLElement>('[data-upload-status]');
  const hint = root.querySelector<HTMLElement>('[data-drop-hint]');

  const uploadingLabel = hint?.dataset.uploading ?? 'Uploading…';

  const send = async (files: FileList | File[]): Promise<void> => {
    if (!form || files.length === 0) return;

    const data = new FormData();
    data.append('_token', root.dataset.csrf ?? '');
    for (const file of Array.from(files).slice(0, 12)) {
      data.append('images[]', file);
    }

    setStatus(status, uploadingLabel, 'busy');

    try {
      const result = await upload(form.action, data, (percent) => {
        setStatus(status, `${uploadingLabel} ${percent}%`, 'busy');
      });

      await refreshGallery(root);

      if (result.ok) {
        const added = result.added?.length ?? 0;
        const rejected = result.rejected?.length ?? 0;
        setStatus(
          status,
          rejected > 0 ? `${added} ✓ · ${rejected} ✕` : `${added} ✓`,
          rejected > 0 ? 'error' : 'ok',
        );
      } else {
        setStatus(status, (result.rejected ?? [result.error ?? 'failed']).join(', '), 'error');
      }
    } catch {
      // Fall back to the plain form post, which always works.
      form.submit();
      return;
    }

    if (input) input.value = '';
    window.setTimeout(() => setStatus(status, '', null), 6000);
  };

  input?.addEventListener('change', () => {
    if (input.files && input.files.length > 0) {
      void send(input.files);
    }
  });

  if (zone) {
    const stop = (event: DragEvent): void => {
      event.preventDefault();
      event.stopPropagation();
    };

    for (const type of ['dragenter', 'dragover'] as const) {
      zone.addEventListener(type, (event) => {
        stop(event);
        zone.classList.add('is-hovered');
      });
    }
    for (const type of ['dragleave', 'dragend'] as const) {
      zone.addEventListener(type, (event) => {
        stop(event);
        zone.classList.remove('is-hovered');
      });
    }
    zone.addEventListener('drop', (event) => {
      stop(event);
      zone.classList.remove('is-hovered');
      const dropped = event.dataTransfer?.files;
      if (dropped && dropped.length > 0) {
        void send(dropped);
      }
    });

    // A file dropped anywhere else would otherwise navigate away from the page
    // and silently lose whatever the person was doing.
    for (const type of ['dragover', 'drop'] as const) {
      window.addEventListener(type, (event) => {
        if (!zone.contains(event.target as Node)) {
          event.preventDefault();
        }
      });
    }
  }

  // Set-primary and remove, submitted in the background.
  root.addEventListener('submit', (event) => {
    const submitted = event.target;
    if (!(submitted instanceof HTMLFormElement) || submitted === form) return;

    const confirmText = submitted.dataset.confirm;
    if (confirmText && !window.confirm(confirmText)) {
      event.preventDefault();
      return;
    }

    event.preventDefault();
    const shot = submitted.closest<HTMLElement>('.adm-shot');
    shot?.classList.add('is-busy');

    void (async () => {
      try {
        const response = await fetch(submitted.action, {
          method: 'POST',
          body: new FormData(submitted),
          headers: { 'X-Requested-With': 'fetch', Accept: 'application/json' },
          credentials: 'same-origin',
        });
        if (!response.ok) {
          throw new Error('rejected');
        }
        await refreshGallery(root);
      } catch {
        submitted.submit();
      } finally {
        shot?.classList.remove('is-busy');
      }
    })();
  });
}

/** The admin sidebar on small screens. */
export function initAdminNav(): void {
  const toggle = document.querySelector<HTMLButtonElement>('[data-adm-menu]');
  const nav = document.getElementById('adm-nav');
  if (!toggle || !nav) return;

  toggle.addEventListener('click', () => {
    const open = nav.classList.toggle('is-open');
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
}

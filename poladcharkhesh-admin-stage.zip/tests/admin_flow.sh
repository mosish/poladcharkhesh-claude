#!/usr/bin/env bash
#
# End-to-end check of the admin panel.
#
# Exercises the whole path a person takes — first-run setup, sign-in, uploading
# an image, making it primary, removing it — and, just as importantly, the
# paths an attacker takes: unauthenticated access, a missing CSRF token, a PHP
# script wearing a .jpg extension, and repeated failed sign-ins.
#
# Run against a development server:
#   php -S 127.0.0.1:8080 -t public &
#   bash tests/admin_flow.sh
#
set -uo pipefail

BASE="${BASE_URL:-http://127.0.0.1:8080}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORK="$(mktemp -d)"
JAR="$WORK/cookies.txt"
PASS=0
FAIL=0

# The suite signs in, uploads and deletes, all of which write to the data
# store. It works on a snapshot and puts the originals back afterwards, so a
# test run never leaves its fingerprints in committed data.
SNAPSHOT="$WORK/store-snapshot"
restore() {
  if [ -d "$SNAPSHOT" ]; then
    cp -a "$SNAPSHOT"/. "$ROOT/data/store/" 2>/dev/null || true
  fi
  find "$ROOT/public/assets/uploads/products" -mindepth 1 ! -name '.gitkeep' -delete 2>/dev/null || true
  rm -rf "$WORK"
}
trap restore EXIT

ok()   { printf '  \033[32mPASS\033[0m  %s\n' "$1"; PASS=$((PASS+1)); }
bad()  { printf '  \033[31mFAIL\033[0m  %s — %s\n' "$1" "${2:-}"; FAIL=$((FAIL+1)); }
section() { printf '\n\033[1m%s\033[0m\n' "$1"; }

expect_status() { # description, expected, actual
  if [ "$2" = "$3" ]; then ok "$1"; else bad "$1" "expected $2, got $3"; fi
}

status() { curl -s -o /dev/null -w '%{http_code}' "$@"; }

csrf_from() { # file -> token
  grep -o 'name="_token" value="[a-f0-9]*"' "$1" | head -1 | sed 's/.*value="//;s/"//'
}

# --------------------------------------------------------------------------
section "Reset admin state"
mkdir -p "$SNAPSHOT"
cp -a "$ROOT"/data/store/. "$SNAPSHOT"/
ok "snapshotted the data store"
rm -f "$ROOT"/data/store/{admins,sessions,throttle}.json
rm -rf "$ROOT"/public/assets/uploads/products/test-fixture
echo '[]' > "$ROOT/data/store/admins.json"
echo '[]' > "$ROOT/data/store/sessions.json"
echo '[]' > "$ROOT/data/store/throttle.json"
ok "cleared admins, sessions and throttle"

# --------------------------------------------------------------------------
section "Unauthenticated access is refused"
for path in /admin /admin/products /admin/media /admin/audit; do
  expect_status "GET $path redirects" 302 "$(status "$BASE$path")"
done
expect_status "POST upload without a session" 302 \
  "$(status -X POST "$BASE/admin/products/6204-2rs/images")"

# --------------------------------------------------------------------------
section "First-run setup"
expect_status "setup page is reachable while unprovisioned" 200 "$(status "$BASE/admin/setup")"

expect_status "weak password refused" 422 "$(status -X POST "$BASE/admin/setup" \
  -d 'name=Test Owner' -d 'username=owner' -d 'email=' \
  -d 'password=password123' -d 'password_confirm=password123')"

expect_status "mismatched confirmation refused" 422 "$(status -X POST "$BASE/admin/setup" \
  -d 'name=Test Owner' -d 'username=owner' -d 'email=' \
  -d 'password=correct-horse-battery' -d 'password_confirm=different-value-here')"

SETUP_CODE=$(curl -s -o "$WORK/setup.html" -w '%{http_code}' -c "$JAR" -X POST "$BASE/admin/setup" \
  -d 'name=Test Owner' -d 'username=owner' -d 'email=owner@example.test' \
  -d 'password=correct-horse-battery' -d 'password_confirm=correct-horse-battery')
expect_status "valid setup succeeds" 302 "$SETUP_CODE"

if grep -q 'pc_admin' "$JAR"; then ok "session cookie issued"; else bad "session cookie issued" "no pc_admin in jar"; fi
if grep -q 'HttpOnly' "$JAR" || grep -qi '#HttpOnly' "$JAR"; then
  ok "session cookie is HttpOnly"
else
  bad "session cookie is HttpOnly" "flag missing"
fi

expect_status "setup closes once provisioned" 302 "$(status "$BASE/admin/setup")"

# Password hash never lands in the store in plaintext form.
if grep -q 'correct-horse-battery' "$ROOT/data/store/admins.json"; then
  bad "password not stored in plaintext" "found the password in admins.json"
else
  ok "password not stored in plaintext"
fi
if grep -qE '"passwordHash": *"\$(argon2id|2y)' "$ROOT/data/store/admins.json"; then
  ok "password stored as an Argon2id or bcrypt hash"
else
  bad "password hashing" "unexpected hash format"
fi
# The session token itself must not be recoverable from the store.
COOKIE_TOKEN=$(grep pc_admin "$JAR" | awk '{print $NF}')
if [ -n "$COOKIE_TOKEN" ] && grep -q "$COOKIE_TOKEN" "$ROOT/data/store/sessions.json"; then
  bad "session token is not stored" "raw token present in sessions.json"
else
  ok "session token is not stored, only its digest"
fi

# --------------------------------------------------------------------------
section "Signed-in access"
expect_status "overview" 200 "$(status -b "$JAR" "$BASE/admin")"
expect_status "products" 200 "$(status -b "$JAR" "$BASE/admin/products")"
expect_status "media" 200 "$(status -b "$JAR" "$BASE/admin/media")"
expect_status "audit" 200 "$(status -b "$JAR" "$BASE/admin/audit")"
expect_status "unknown product" 404 "$(status -b "$JAR" "$BASE/admin/products/does-not-exist")"

curl -s -b "$JAR" -o "$WORK/editor.html" "$BASE/admin/products/6204-2rs"
TOKEN=$(csrf_from "$WORK/editor.html")
if [ -n "$TOKEN" ]; then ok "editor page issues a CSRF token"; else bad "CSRF token" "none found"; fi

# --------------------------------------------------------------------------
section "CSRF protection"
expect_status "upload without a token" 419 \
  "$(status -b "$JAR" -X POST "$BASE/admin/products/6204-2rs/images")"
expect_status "upload with a wrong token" 419 \
  "$(status -b "$JAR" -X POST "$BASE/admin/products/6204-2rs/images" -F "_token=deadbeef")"
expect_status "delete without a token" 419 \
  "$(status -b "$JAR" -X POST "$BASE/admin/products/6204-2rs/images/delete" -F 'url=/x.webp')"

# --------------------------------------------------------------------------
section "Upload validation"

# A PHP script with an image extension and an image content type.
printf '<?php echo "executed"; ?>' > "$WORK/payload.jpg"
UP=$(curl -s -b "$JAR" -H 'X-Requested-With: fetch' -X POST "$BASE/admin/products/6204-2rs/images" \
  -F "_token=$TOKEN" -F 'images[]=@'"$WORK/payload.jpg"';type=image/jpeg')
if echo "$UP" | grep -q 'notAnImage'; then ok "PHP script disguised as .jpg is refused"; else bad "disguised script refused" "$UP"; fi

# A real image with a .php extension, to prove the extension is never trusted
# in either direction.
php -r '$i=imagecreatetruecolor(800,600);
        imagefilledrectangle($i,0,0,800,600,imagecolorallocate($i,240,242,246));
        imagefilledellipse($i,400,300,420,420,imagecolorallocate($i,150,163,186));
        imagefilledellipse($i,400,300,180,180,imagecolorallocate($i,240,242,246));
        imagepng($i,"'"$WORK"'/real.php");' 2>/dev/null
UP=$(curl -s -b "$JAR" -H 'X-Requested-With: fetch' -X POST "$BASE/admin/products/6204-2rs/images" \
  -F "_token=$TOKEN" -F 'images[]=@'"$WORK/real.php"';type=application/x-php')
if echo "$UP" | grep -q '"ok":true'; then ok "genuine image accepted whatever its extension"; else bad "genuine image accepted" "$UP"; fi

# A tiny image is not a product photograph.
php -r '$i=imagecreatetruecolor(48,48); imagepng($i,"'"$WORK"'/tiny.png");' 2>/dev/null
UP=$(curl -s -b "$JAR" -H 'X-Requested-With: fetch' -X POST "$BASE/admin/products/6204-2rs/images" \
  -F "_token=$TOKEN" -F 'images[]=@'"$WORK/tiny.png")
if echo "$UP" | grep -q 'tooSmall'; then ok "undersized image refused"; else bad "undersized image refused" "$UP"; fi

# One of the corrupt imported files must not sneak back in through upload.
BROKEN=$(ls "$ROOT"/public/assets/images/*.webp 2>/dev/null | head -1)
if [ -n "$BROKEN" ]; then
  UP=$(curl -s -b "$JAR" -H 'X-Requested-With: fetch' -X POST "$BASE/admin/products/6204-2rs/images" \
    -F "_token=$TOKEN" -F 'images[]=@'"$BROKEN")
  if echo "$UP" | grep -qE 'notAnImage|undecodable'; then ok "corrupt imported file refused on upload"; else bad "corrupt file refused" "$UP"; fi
fi

# --------------------------------------------------------------------------
section "The uploaded image reaches the public site"
curl -s -b "$JAR" -o "$WORK/editor2.html" "$BASE/admin/products/6204-2rs"
UPLOADED=$(grep -o '/assets/uploads/products/6204-2rs/[a-f0-9]*\.\(webp\|jpg\)' "$WORK/editor2.html" | head -1)
if [ -n "$UPLOADED" ]; then ok "editor lists the uploaded file"; else bad "editor lists the upload" "none found"; fi

if [ -n "$UPLOADED" ]; then
  expect_status "uploaded file is served" 200 "$(status "$BASE$UPLOADED")"
  TYPE=$(curl -s -o /dev/null -w '%{content_type}' "$BASE$UPLOADED")
  case "$TYPE" in
    image/*) ok "served with an image content type ($TYPE)" ;;
    *)       bad "served as an image" "got $TYPE" ;;
  esac
fi

if curl -s "$BASE/?lang=en" | grep -q '/assets/uploads/products/6204-2rs/'; then
  ok "the public home page now renders the uploaded photograph"
else
  bad "public page shows the upload" "still falling back to the schematic"
fi

# --------------------------------------------------------------------------
section "Primary image and removal"
FIRST=$(grep -o '/assets/uploads/products/6204-2rs/[a-f0-9]*\.\(webp\|jpg\)' "$WORK/editor2.html" | head -1)
TOKEN2=$(csrf_from "$WORK/editor2.html")

RESP=$(curl -s -b "$JAR" -H 'X-Requested-With: fetch' -X POST "$BASE/admin/products/6204-2rs/images/primary" \
  -F "_token=$TOKEN2" -F "url=$FIRST")
if echo "$RESP" | grep -q '"ok":true'; then ok "primary image can be changed"; else bad "set primary" "$RESP"; fi

RESP=$(curl -s -b "$JAR" -H 'X-Requested-With: fetch' -X POST "$BASE/admin/products/6204-2rs/images/primary" \
  -F "_token=$TOKEN2" -F 'url=/assets/uploads/products/other/nope.webp')
if echo "$RESP" | grep -q 'unknownImage'; then ok "an image from another product is refused"; else bad "cross-product refusal" "$RESP"; fi

RESP=$(curl -s -b "$JAR" -H 'X-Requested-With: fetch' -X POST "$BASE/admin/products/6204-2rs/images/delete" \
  -F "_token=$TOKEN2" -F "url=$FIRST")
if echo "$RESP" | grep -q '"ok":true'; then ok "image can be removed"; else bad "remove image" "$RESP"; fi

if [ ! -f "$ROOT/public$FIRST" ]; then ok "the file was deleted from disk"; else bad "file deleted" "still present"; fi

# --------------------------------------------------------------------------
section "Engineering data is unreachable from the image routes"
BEFORE=$(php -r '$p=json_decode(file_get_contents("'"$ROOT"'/data/store/products.json"),true);
                 foreach($p as $x){if($x["slug"]==="6204-2rs"){echo $x["crKn"],"|",$x["d"],"|",$x["D"];}}')
curl -s -b "$JAR" -X POST "$BASE/admin/products/6204-2rs/images/primary" \
  -F "_token=$TOKEN2" -F 'url=/x' -F 'crKn=999' -F 'd=1' -F 'D=2' -o /dev/null
AFTER=$(php -r '$p=json_decode(file_get_contents("'"$ROOT"'/data/store/products.json"),true);
                foreach($p as $x){if($x["slug"]==="6204-2rs"){echo $x["crKn"],"|",$x["d"],"|",$x["D"];}}')
if [ "$BEFORE" = "$AFTER" ]; then ok "load rating and dimensions unchanged by a crafted request"; else bad "mass assignment" "$BEFORE -> $AFTER"; fi

# --------------------------------------------------------------------------
section "Sign out"
LOGOUT=$(status -b "$JAR" -c "$JAR" -X POST "$BASE/admin/logout" -d "_token=$TOKEN2")
expect_status "logout redirects" 302 "$LOGOUT"
expect_status "the session no longer works" 302 "$(status -b "$JAR" "$BASE/admin/products")"

# --------------------------------------------------------------------------
section "Sign-in throttling"
for i in 1 2 3 4 5; do
  curl -s -o /dev/null -X POST "$BASE/admin/login" -d 'username=owner' -d 'password=wrong-guess'
done
CODE=$(status -X POST "$BASE/admin/login" -d 'username=owner' -d 'password=wrong-guess')
expect_status "locked out after repeated failures" 429 "$CODE"
CODE=$(status -X POST "$BASE/admin/login" -d 'username=owner' -d 'password=correct-horse-battery')
expect_status "the correct password is refused while locked" 429 "$CODE"

# A clean slate, then a real sign-in.
echo '[]' > "$ROOT/data/store/throttle.json"
CODE=$(curl -s -o /dev/null -w '%{http_code}' -c "$JAR" -X POST "$BASE/admin/login" \
  -d 'username=owner' -d 'password=correct-horse-battery')
expect_status "correct credentials sign in" 302 "$CODE"
expect_status "and the session works" 200 "$(status -b "$JAR" "$BASE/admin")"

# --------------------------------------------------------------------------
section "Audit log"
curl -s -b "$JAR" -o "$WORK/audit.html" "$BASE/admin/audit"
for action in LOGIN MEDIA_UPLOADED MEDIA_DELETED CSRF_REJECTED LOGIN_FAILED; do
  if grep -q "$action" "$WORK/audit.html"; then ok "records $action"; else bad "records $action" "missing"; fi
done
if grep -qiE 'correct-horse-battery|passwordHash|pc_admin' "$ROOT/data/store/audit.json"; then
  bad "no secrets in the audit log" "found a credential"
else
  ok "no secrets in the audit log"
fi

# --------------------------------------------------------------------------
printf '\n\033[1m%d passed, %d failed\033[0m\n' "$PASS" "$FAIL"
[ "$FAIL" -eq 0 ]
